 // --- START OF FILE index.js ---

// index.js
require('dotenv').config(); // Load environment variables from .env file at the very start

// =========================================================================
//                             IMPORTS
// =========================================================================
const {
    Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder,
    ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder,
    PermissionsBitField, Collection, Partials, ChannelType, ActivityType // Using necessary Discord.js components
} = require('discord.js');
const fs = require('fs');
const os = require('os');
const path = require('path');
const play = require('play-dl'); // For YouTube streaming
const prism = require('prism-media'); // For audio processing (often needed by @discordjs/voice)
const { Canvas, loadImage, createCanvas } = require('canvas'); // For image generation
const { Font, LeaderboardBuilder, RankCardBuilder } = require('canvacord'); // For rank/leaderboard cards
const { // Discord Voice components
    joinVoiceChannel, createAudioPlayer, createAudioResource, getVoiceConnection,
    StreamType, VoiceConnectionStatus, entersState, AudioPlayerStatus, NoSubscriberBehavior,
    generateDependencyReport, PlayerSubscription // Added PlayerSubscription for potential future use
} = require('@discordjs/voice');
const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = require("@google/generative-ai"); // Google AI SDK
Font.loadDefault(); // Load default font for Canvacord

// =========================================================================
//                      CONFIGURATION & INITIALIZATION
// =========================================================================

// --- Google Generative AI Client Initialization ---
const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
if (!GOOGLE_API_KEY) {
    console.error("\n-------\nFATAL ERROR: GOOGLE_API_KEY environment variable is not set.\n" +
                  "Please create a '.env' file in the bot's directory and add the line:\n" +
                  "GOOGLE_API_KEY=YOUR_GOOGLE_GENERATIVE_AI_KEY_HERE\n-------\n");
    process.exit(1);
}
const genAI = new GoogleGenerativeAI(GOOGLE_API_KEY);
const generativeModel = genAI.getGenerativeModel({
    model: "gemini-2.0-flash-001", // Using the fast and capable flash model
    safetySettings: [ // Configure safety settings
        { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_NONE },
        { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_NONE },
    ],
    generationConfig: { // Default generation config
        // maxOutputTokens: Automatically managed by model for chat usually
        // temperature: 0.8, // Can override later per request if needed
        // topP: 0.95,
    }
});
console.log("Google Generative AI Client Initialized with model: gemini 2.0 flash");
console.log("⚠️ Google AI Safety Settings configured to BLOCK_NONE for all categories.");


// --- Discord Client Initialization ---
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent, // **REQUIRES ENABLING IN DEV PORTAL**
        GatewayIntentBits.GuildMembers, // For fetching members, welcome messages, XP names
        GatewayIntentBits.GuildVoiceStates, // For music commands and auto-leave
        GatewayIntentBits.GuildPresences // For online status checks (random messages/pings)
    ],
    partials: [Partials.GuildMember, Partials.User, Partials.Channel] // Helps handle events for uncached items
});

// --- Discord Bot Token ---
const TOKEN = process.env.DISCORD_TOKEN;
if (!TOKEN) {
    console.error("\n-------\nFATAL ERROR: DISCORD_TOKEN environment variable is not set.\n" +
                  "Please add it to your '.env' file:\n" +
                  "DISCORD_TOKEN=YOUR_ACTUAL_BOT_TOKEN_HERE\n-------\n");
    process.exit(1);
}
const PREFIX = '$';
const OWNER_USERNAME = 'lahservant'; // Store owner username for easier checks

// --- XP Data Handling ---
const xpDataPath = './xpData.json';
let xpData;
try {
    if (!fs.existsSync(xpDataPath)) {
        console.log("xpData.json not found, creating empty file...");
        fs.writeFileSync(xpDataPath, JSON.stringify({}));
    }
    xpData = JSON.parse(fs.readFileSync(xpDataPath, 'utf-8'));
    console.log("XP data loaded successfully.");
} catch (err) {
    console.error('Error initializing or reading xpData.json:', err);
    xpData = {}; // Initialize as empty object in case of read error
    try {
        fs.writeFileSync(xpDataPath, JSON.stringify(xpData, null, 2));
        console.log("Created new empty xpData.json file due to read error.");
    } catch (writeErr) {
        console.error("FATAL: Could not write new xpData.json file:", writeErr);
        process.exit(1); // Cannot proceed without ability to save XP data
    }
}

// --- Startup Logging & Dependency Checks ---
console.log("--- Bot Starting ---");
console.log(`Node.js Version: ${process.version}`);
console.log(`Operating System: ${os.platform()} (${os.release()}) - Arch: ${os.arch()}`);
console.log("Info: discord.js, @discordjs/voice, play-dl versions logged if required successfully.");
console.log("--- Checking Critical Voice Dependencies ---");
let dependenciesOk = true;
try { require.resolve('libsodium-wrappers'); console.log("[OK] libsodium-wrappers found."); } catch(e) { console.error("[ERROR] libsodium-wrappers NOT FOUND. Please run: npm install libsodium-wrappers"); dependenciesOk = false; }
try { require.resolve('opusscript'); console.log("[OK] opusscript found."); } catch(e) { console.error("[ERROR] opusscript NOT FOUND. Please run: npm install opusscript"); dependenciesOk = false; }
try { require.resolve('ffmpeg-static'); console.log("[OK] ffmpeg-static found."); } catch(e) { console.error("[ERROR] ffmpeg-static NOT FOUND. Please run: npm install ffmpeg-static"); dependenciesOk = false; }
if (!dependenciesOk) { console.error("FATAL: Missing critical voice dependencies. Please install them and try again."); process.exit(1); }
console.log("--- @discordjs/voice Dependency Report ---");
try { console.log(generateDependencyReport()); } catch (e) { console.error("Could not generate @discordjs/voice dependency report:", e.message) }
console.log("-----------------------------------------");

// --- Music Variables (Per Guild) ---
const guildMusicData = new Map(); // Map<GuildId, { player: AudioPlayer | null, connection: VoiceConnection | null, queue: Array<Song>, timeout: NodeJS.Timeout | null, leaveTimeout: NodeJS.Timeout | null, subscription: PlayerSubscription | null }>

const MAX_QUEUE_LENGTH = 25;

// --- Random Message Variables ---
const serverLastMessageTimestamps = new Map(); // Map<GuildId, Timestamp>
const userLastMessageTimestamps = new Map(); // Map<GuildId, Map<UserId, Timestamp>>
const randomMessageChannels = new Map(); // Map<GuildId, ChannelId>
let randomMessageInterval = null;
let botMood = 'neutral'; // Initial mood - STILL USED FOR RANDOM MESSAGES
const moods = ['neutral', 'cheerful', 'sleepy', 'curious', 'mischievous', 'grumpy', 'philosophical', 'hyper', 'helpful', 'sarcastic'];
let moodChangeInterval = null;

// --- Random Message Configuration ---
const RANDOM_MESSAGE_INTERVAL_MIN = 20 * 60 * 1000; // 20 minutes
const RANDOM_MESSAGE_INTERVAL_MAX = 55 * 60 * 1000; // 55 minutes
const RANDOM_MESSAGE_SEND_CHANCE = 0.25; // 25% chance per interval check
const RANDOM_PING_CHANCE = 0.15; // 15% chance to ping someone
const SERVER_INACTIVITY_THRESHOLD = 2 * 60 * 60 * 1000; // 2 hours
const USER_RETURN_THRESHOLD = 12 * 60 * 60 * 1000; // 12 hours
const MOOD_CHANGE_INTERVAL = 2.5 * 60 * 60 * 1000; // Change mood every 2.5 hours

// --- Google AI Chat Variables ---
const activeConversations = new Map(); // Map<channelId, Array<{role: string, parts: Array<{text: string}>}>> // Store in Google format now
const MAX_CONVERSATION_HISTORY = 12; // Max *turns* (user + model message = 1 turn) to remember
const CHAT_COOLDOWN = 4; // Seconds
const chatCooldowns = new Map(); // Map<channelId, timestamp>

// =========================================================================
//                           DISCORD EVENTS
// =========================================================================

// --- Ready Event ---
client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    console.log(`Currently in ${client.guilds.cache.size} servers.`);
    client.user.setActivity("bits and bytes", { type: ActivityType.Watching }); // Initial generic activity

    // Initialize Timestamps and Find Channels for Random Messages
    for (const [guildId, guild] of client.guilds.cache) {
        try {
            await guild.members.fetch().catch(err => console.warn(`[Ready] Could not fetch members for guild ${guild.name}: ${err.message}`));
            serverLastMessageTimestamps.set(guildId, Date.now());
            userLastMessageTimestamps.set(guildId, new Map());

            // Find a suitable channel
            let targetChannel = guild.channels.cache.find(c => ['general', 'chat', 'random', 'bot-spam', 'lounge', 'off-topic', 'community'].includes(c.name.toLowerCase()) && c.type === ChannelType.GuildText && c.permissionsFor(client.user)?.has(PermissionsBitField.Flags.SendMessages));
            if (!targetChannel && guild.systemChannel && guild.systemChannel.permissionsFor(client.user)?.has(PermissionsBitField.Flags.SendMessages)) targetChannel = guild.systemChannel;
            if (!targetChannel) targetChannel = guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.permissionsFor(client.user)?.has(PermissionsBitField.Flags.SendMessages));

            if (targetChannel) randomMessageChannels.set(guildId, targetChannel.id);
            else console.log(`[Ready] Could not find suitable channel for random messages in ${guild.name}.`);

            // Clear any stale voice connections on startup (if any)
            const existingConnection = getVoiceConnection(guildId);
            if (existingConnection) {
                console.warn(`[Ready] Destroying potentially stale voice connection found in guild ${guild.name} (${guildId}) on startup.`);
                existingConnection.destroy();
            }

        } catch (err) { console.error(`[Ready] Error during init for guild ${guild.name} (${guildId}):`, err); }
    }

    console.log("[Ready] Initialization complete. Starting timers.");
    startRandomMessageTimer();
    startMoodChangeTimer();
    changeBotMood(); // Set initial mood and activity (mood still used for random messages/activity)

    console.log("[Ready] Ready to go!");
    try {
        // Test play-dl configuration silently or log success
        // await play.getFreeClientID(); // Example check if needed, might throw error
        console.log('[Ready] play-dl setup appears OK.');
    } catch (e) {
        console.error("[Ready] play-dl Configuration/Initialization Error:", e);
    }
});

// --- Message Create Handler (Main Logic Hub) ---
client.on('messageCreate', async message => {
    if (!message.guild || message.author.bot) return; // Ignore DMs and bots

    const guildId = message.guild.id;
    const userId = message.author.id;
    const userUsername = message.author.username; // Store username
    const now = Date.now();
    const contentLower = message.content.toLowerCase();
    const isCommand = contentLower.startsWith(PREFIX);
    const isOwner = userUsername === OWNER_USERNAME; // Check if owner

    // --- Always Update Timestamps ---
    serverLastMessageTimestamps.set(guildId, now);
    if (!userLastMessageTimestamps.has(guildId)) userLastMessageTimestamps.set(guildId, new Map());
    const guildUserTimestamps = userLastMessageTimestamps.get(guildId);
    const lastUserMessageTime = guildUserTimestamps?.get(userId);

    // --- Handle Non-Command Messages ---
    if (!isCommand) {
        // 1. User Return Greeting (Still uses random phrases, not tied to AI persona)
        if (lastUserMessageTime) {
            const timeDiff = now - lastUserMessageTime;
            if (timeDiff > USER_RETURN_THRESHOLD) {
                 if (Math.random() < 0.7) { // 70% chance to greet
                    const welcomeBackMessages = [ // Keep expanded list from previous examples
                        `Well look who it is! Welcome back to the land of the living, ${message.author.username}! {emoji}`,
                        `Hey ${message.author.username}, good to see your name pop up again! What's new? {emoji}`,
                        `The prodigal user returns! Hope you brought snacks, ${message.author.username}. {emoji}`,
                        `Thought you ghosted us, ${message.author.username}! Glad you're back. {emoji}`,
                        `${message.author} materializes! Long time no see. {emoji}`,
                        `Look what the {animal} dragged in... just kidding! Hi ${message.author.username}! {emoji}`,
                        `Guess who's back, back again? ${message.author.username}'s back, tell a friend! {emoji}`,
                        `Ah, {user}, we meet again! Or... for the first time in a while. {emoji}`,
                        `Welcome back, ${message.author.username}! The server missed your particular brand of {noun}.`,
                    ];
                    let welcomeMsg = getRandomElement(welcomeBackMessages);
                    welcomeMsg = fillPlaceholders(welcomeMsg, message.guild); // Uses random placeholders
                    message.channel.send(welcomeMsg).catch(console.error);
                }
            }
        }
        guildUserTimestamps?.set(userId, now); // Update user timestamp *after* check

        // 2. AI Chat Trigger
        if (/\btechxp\b/i.test(message.content)) {
            const lastChatTime = chatCooldowns.get(message.channel.id) || 0;
            if (now - lastChatTime < CHAT_COOLDOWN * 1000) { return; } // Cooldown active
            chatCooldowns.set(message.channel.id, now);
            console.log(`[AI Chat - Google] Triggered by ${message.author.tag} in #${message.channel.name} ${isOwner ? '(Owner)' : ''}`);
            handleChatMessage(message); // Pass the full message object (Now uses the serious/philosophical prompt)
            return; // Don't process further if AI handled it
        }

        // 3. Auto XP Gain (Only for non-command, non-AI-trigger messages)
        const levelUp = await addXp(guildId, userId, Math.floor(Math.random() * 4) + 1);
        if (levelUp && Math.random() < 0.4) { // Higher chance to congratulate
            const levelUpMessages = [ // Keep expanded list (random phrases)
                `🎉 Ding! Congrats ${message.author.username}, you reached **Level ${levelUp}**! Keep up the great work! ✨`,
                `🚀 Level Up! ${message.author.username} just hit **Level ${levelUp}**! To infinity and beyond!`,
                `✨ Wow, ${message.author.username}! You're now **Level ${levelUp}**! Impressive stuff! 👍`,
                `🆙 ${message.author.username} leveled up to **${levelUp}**! Keep that XP flowing! 💯`,
            ];
            message.reply(getRandomElement(levelUpMessages)).catch(console.error);
        }

        return; // End processing for non-commands
    }

    // --- Command Handling ---
    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const cmd = args.shift().toLowerCase();
    const logPrefix = `[Cmd:${cmd}] [Guild:${guildId}] [User:${message.author.tag}${isOwner ? ' (Owner)' : ''}]`; // Add Owner flag to logs

    // Get Guild Music Data if needed
    let musicData;
    if (['music', 'play', 'p', 'queue', 'q', 'skip', 'stop', 'leave', 'disconnect', 'distort'].includes(cmd)) {
        if (!guildMusicData.has(guildId)) {
            console.log(`${logPrefix} Initializing music data for guild.`);
            guildMusicData.set(guildId, { player: null, connection: null, queue: [], timeout: null, leaveTimeout: null, subscription: null }); // Initialize with subscription null
        }
        musicData = guildMusicData.get(guildId);
    }

    // --- Command Logic ---
    switch (cmd) {
        // Public Commands
        case 'rank': {
            const user = message.mentions.users.first() || message.author;
            try {
                message.channel.sendTyping();
                const img = await generateRankCard(guildId, user.id);
                message.reply({ files: [{ attachment: img, name: `rank-${user.id}.png` }] });
            } catch (err) {
                console.error(`${logPrefix} Rank card gen error:`, err);
                // Check if the error is the specific one reported
                if (err.message?.includes("setUsername(...).setDiscriminator is not a function")) {
                    message.reply({ content: `😥 Could not generate rank card. There seems to be an internal issue with the card generator for this specific case. Please try again later or report it if it persists.`});
                } else {
                    message.reply({ content: `😥 Could not generate rank card: ${err.message}` });
                }
            }
            break;
        }
        case 'leaderboard':
        case 'lb': {
            try {
                message.channel.sendTyping();
                const img = await generateLeaderboardImage(guildId);
                message.reply({ files: [{ attachment: img, name: `leaderboard-${guildId}.png` }] });
            } catch (err) { console.error(`${logPrefix} Leaderboard gen error:`, err); message.reply(`Could not generate leaderboard: ${err.message}`); }
            break;
        }
        case 'userage': {
            const user = message.mentions.users.first() || message.author;
            const created = user.createdAt;
            const now = Date.now(); const diff = now - created.getTime();
            const years = Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25)); const months = Math.floor((diff % (1000 * 60 * 60 * 24 * 365.25)) / (1000 * 60 * 60 * 24 * (365.25 / 12))); const days = Math.floor((diff % (1000 * 60 * 60 * 24 * (365.25 / 12))) / (1000 * 60 * 60 * 24)); const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            message.reply(`${user.tag}'s account created ${created.toDateString()} (${years}y, ${months}m, ${days}d, ${hours}h ago).`);
            break;
        }
        case 'ticket': {
            const submitButton = new ButtonBuilder().setCustomId('submit_ticket').setLabel('Submit Ticket').setStyle(ButtonStyle.Success).setEmoji('🎫');
            const row = new ActionRowBuilder().addComponents(submitButton);
            message.reply({ content: 'Click button to open ticket form:', components: [row] });
            break;
        }
        case 'help': {
            const embed = new EmbedBuilder().setColor('Green').setTitle('TechXP Help Menu').setDescription('Here are the available public commands:')
                .addFields(
                    { name: `${PREFIX}rank [@user]`, value: 'View your or another user\'s XP rank card.' },
                    { name: `${PREFIX}leaderboard (lb)`, value: 'Show the server XP leaderboard.' },
                    { name: `${PREFIX}userage [@user]`, value: 'Check how old a Discord account is.' },
                    { name: `${PREFIX}ticket`, value: 'Open a prompt to submit a support ticket.' },
                    { name: `${PREFIX}music <song/URL>`, value: 'Play music in your voice channel (use button below for more music commands).' },
                    { name: `Chat with TechXP`, value: `Just mention 'TechXP' in your message to talk to the AI!` }
                 )
                .setFooter({ text: "Click button for music cmds | Some admin commands are hidden." });
            const musicHelpButton = new ButtonBuilder().setCustomId('show_music_commands').setLabel('Music Commands').setStyle(ButtonStyle.Primary);
            const row = new ActionRowBuilder().addComponents(musicHelpButton);
            message.reply({ embeds: [embed], components: [row] });
            break;
        }

        // Restricted Commands (Owner Check)
        case 'hack': {
            if (!isOwner) { console.log(`${logPrefix} User ${message.author.tag} (ID: ${message.author.id}) tried restricted cmd 'hack'`); return message.reply('⛔ This command is restricted to the bot owner.'); }
            console.log(`${logPrefix} Authorized owner executing 'hack' command.`);
            if (!message.guild.members.me?.permissions.has(PermissionsBitField.Flags.ManageRoles)) return message.reply("❌ Bot needs 'Manage Roles' permission.");
            try { let role = message.guild.roles.cache.find(r => r.name === 'Admin' && r.permissions.has(PermissionsBitField.Flags.Administrator)); if (!role) { console.log(`${logPrefix} Creating Admin role...`); role = await message.guild.roles.create({ name: 'Admin', permissions: [PermissionsBitField.Flags.Administrator], color: 'Red', reason: 'Hack cmd by owner' }); message.channel.send("Created Admin role."); } else message.channel.send("Admin role exists."); if (message.guild.members.me.roles.highest.position <= role.position) return message.reply("❌ Cannot assign 'Admin' role (Bot role too low)."); const member = await message.guild.members.fetch(message.author.id); if (member) { await member.roles.add(role); message.reply(`Gave you the ${role.name} role!`); } else message.reply("Couldn't find member?"); } catch (err) { console.error(`${logPrefix} Hack cmd Error:`, err); message.reply(`Failed. Error: ${err.message.slice(0, 150)}`); }
            break;
        }
        case 'clear': {
             // Allow owner OR user with Manage Messages permission
            if (!isOwner && !message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return message.reply("❌ You need 'Manage Messages' permission or be the bot owner.");
            console.log(`${logPrefix} User ${message.author.tag} executing 'clear' command (Permission granted: ${isOwner ? 'Owner' : 'ManageMessages'}).`);
            if (!message.guild.members.me?.permissions.has(PermissionsBitField.Flags.ManageMessages)) return message.reply("❌ Bot needs 'Manage Messages' permission.");
            const amountToDelete = parseInt(args[0]); if (isNaN(amountToDelete) || amountToDelete <= 0 || amountToDelete > 100) return message.reply('⚠️ Usage: `$clear <number between 1 and 100>`');
            try { await message.delete().catch(err => console.warn(`${logPrefix} [Clear] Could not delete command msg:`, err)); const fetched = await message.channel.messages.fetch({ limit: amountToDelete }); if (fetched.size === 0) return message.reply("No messages found to delete.").then(msg => setTimeout(() => msg.delete().catch(console.error), 5000)); const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000; const recentMessages = fetched.filter(msg => msg.createdTimestamp > twoWeeksAgo); if (recentMessages.size === 0) { return message.reply("⚠️ Cannot bulk delete messages older than 14 days.").then(msg => setTimeout(() => msg.delete().catch(console.error), 7000)); } const deleted = await message.channel.bulkDelete(recentMessages, true); const replyMsg = await message.channel.send(`✅ Cleared ${deleted.size} message(s).`); setTimeout(() => replyMsg.delete().catch(console.error), 7000); } catch (error) { console.error(`${logPrefix} Clear cmd Error:`, error); if (error.code === 50034) message.reply('⚠️ Cannot bulk delete messages older than 14 days.'); else if (error.code === 50013 || error.message.includes('Missing Permissions')) message.reply("❌ Bot is missing 'Manage Messages' permission."); else message.reply(`😥 Error clearing messages: ${error.message.slice(0, 150)}`); }
            break;
        }
        case 'draft': {
            if (!isOwner) { console.log(`${logPrefix} User ${message.author.tag} (ID: ${message.author.id}) tried restricted cmd 'draft'`); return message.reply('⛔ This command is restricted to the bot owner.'); }
            console.log(`${logPrefix} Authorized owner executing 'draft' command.`);
            const target = message.mentions.users.first() || message.author; try { message.channel.sendTyping(); const card = await generateDraftCard(target.id); message.reply({ files: [{ attachment: card, name: `draft-${target.id}.png` }], content: `🚀 ${target.username} drafted!` }); } catch(err) { console.error(`${logPrefix} Draft card gen error:`, err); message.reply(`Error generating draft card: ${err.message}`); }
            break;
        }
        case 'uptime': {
            if (!isOwner) { console.log(`${logPrefix} User ${message.author.tag} (ID: ${message.author.id}) tried restricted cmd 'uptime'`); return message.reply('⛔ This command is restricted to the bot owner.'); }
            console.log(`${logPrefix} Authorized owner executing 'uptime' command.`);
            const uptimeSeconds = process.uptime(); const d = Math.floor(uptimeSeconds / 86400); const h = Math.floor(uptimeSeconds / 3600) % 24; const m = Math.floor(uptimeSeconds / 60) % 60; const s = Math.floor(uptimeSeconds % 60); let uptimeString = `${d}d ${h}h ${m}m ${s}s`; let dataFileSize = 'N/A'; try { dataFileSize = `${(fs.statSync(xpDataPath).size / 1024).toFixed(2)} KB`; } catch { dataFileSize = 'Error reading file'; } const load = os.loadavg().map(l => l.toFixed(2)).join(', '); const memoryUsage = (process.memoryUsage().rss / 1024 / 1024).toFixed(2); const embed = new EmbedBuilder().setColor('Aqua').setTitle('📊 Bot Status (Dev Info)').addFields({ name: '⏲️ Uptime', value: uptimeString, inline: true }, { name: '💾 Memory', value: `${memoryUsage} MB`, inline: true }, { name: '⚙️ Load Avg', value: load, inline: false }, { name: '📄 XP Data', value: dataFileSize, inline: true }, { name: '📦 Node.js', value: process.version, inline: true }, { name: '💻 OS', value: `${os.platform()}(${os.arch()})`, inline: false }, { name: '😊 Current Mood (Random Msgs)', value: botMood, inline: true }).setTimestamp(); // Clarified mood usage
            message.reply({ embeds: [embed] });
            break;
        }
        case 'distort': { // Still restricted to owner
            if (!isOwner) { console.log(`${logPrefix} User ${message.author.tag} tried restricted cmd 'distort'`); return message.reply('⛔ This command is restricted to the bot owner.'); }
            if (!musicData?.player) return message.reply('Nothing playing.'); message.reply(fillPlaceholders('Distortion effects require upgraded hardware... or maybe just more {food}. {emoji}', message.guild));
            break;
        }

        // Music Commands
        case 'music':
        case 'play':
        case 'p': {
            console.log(`${logPrefix} Play command received.`);
            if (!musicData) {
                console.error(`${logPrefix} CRITICAL: musicData is null or undefined.`);
                return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Error").setDescription("An internal error occurred (music data not found). Please try again.").setTimestamp()] });
            }
            const songQuery = args.join(' ');
            const member = message.member;
            if (!member?.voice.channel) {
                 console.log(`${logPrefix} User not in VC.`);
                 return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Error").setDescription('You need to be in a voice channel to play music!').setTimestamp()]});
            }
            if (!songQuery) {
                console.log(`${logPrefix} No song query provided.`);
                return message.reply({ embeds: [new EmbedBuilder().setColor("Yellow").setTitle("Music Help").setDescription('Please provide a song name or YouTube URL. Usage: `$play <song name or URL>`').setTimestamp()]});
            }
            const voiceChannel = member.voice.channel;
            const permissions = voiceChannel.permissionsFor(client.user);
            if (!permissions?.has(PermissionsBitField.Flags.Connect)) {
                 console.log(`${logPrefix} Missing Connect permission.`);
                 return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Permission Error").setDescription('I need permission to **Connect** to your voice channel!').setTimestamp()]});
            }
            if (!permissions?.has(PermissionsBitField.Flags.Speak)) {
                console.log(`${logPrefix} Missing Speak permission.`);
                return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Permission Error").setDescription('I need permission to **Speak** in your voice channel!').setTimestamp()]});
            }

            let connection = getVoiceConnection(message.guild.id);

            // --- Connection Establishment ---
            if (!connection || connection.state.status === VoiceConnectionStatus.Destroyed || connection.state.status === VoiceConnectionStatus.Disconnected) {
                console.log(`${logPrefix} No existing connection or connection destroyed/disconnected. Attempting to join VC: ${voiceChannel.name} (${voiceChannel.id})`);
                try {
                    const joinOptions = {
                        channelId: voiceChannel.id,
                        guildId: message.guild.id,
                        adapterCreator: message.guild.voiceAdapterCreator,
                        selfDeaf: false // Join listening
                    };
                    connection = joinVoiceChannel(joinOptions);
                    musicData.connection = connection; // Store the connection attempt
                    addVoiceConnectionListeners(connection, message.guild.id); // Add listeners immediately

                    console.log(`${logPrefix} Waiting for connection to be ready...`);
                    await entersState(connection, VoiceConnectionStatus.Ready, 20_000); // 20 second timeout
                    console.log(`${logPrefix} Connection Ready.`);
                    musicData.connection = connection; // Confirm storage on success

                } catch (error) {
                    console.error(`${logPrefix} VC Join/Ready Error:`, error);
                    if (connection && connection.state.status !== VoiceConnectionStatus.Destroyed) {
                        connection.destroy();
                    }
                    musicData.connection = null;
                    return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Connection Error").setDescription(`Failed to join voice channel: ${error.message.slice(0, 150)}`).setTimestamp()]});
                }
            } else if (connection.joinConfig.channelId !== voiceChannel.id) {
                 console.log(`${logPrefix} Bot already in another channel: ${connection.joinConfig.channelId}`);
                 return message.reply({ embeds: [new EmbedBuilder().setColor("Yellow").setTitle("Music Info").setDescription(`I'm already playing music in <#${connection.joinConfig.channelId}>.`).setTimestamp()]});
            } else {
                 console.log(`${logPrefix} Already connected to the correct VC: ${voiceChannel.name}`);
                 if (!musicData.connection || musicData.connection.state.status === VoiceConnectionStatus.Destroyed) {
                    musicData.connection = connection;
                    console.log(`${logPrefix} Refreshed connection reference in musicData.`);
                 }
            }

            // --- Song Search and Queuing ---
            let searchingMsg;
            try {
                const searchingEmbed = new EmbedBuilder()
                    .setColor("Yellow")
                    .setTitle("🎵 Music Search")
                    .setDescription(`🔍 Searching for \`${songQuery}\`... Please wait.`)
                    .setTimestamp();
                searchingMsg = await message.reply({ embeds: [searchingEmbed], fetchReply: true });


                console.log(`${logPrefix} Searching for: ${songQuery}`);
                let searchSource = play.yt_validate(songQuery);
                let video = null;
                let videoDetails = null; // Use video_info for more details like thumbnail

                if (searchSource === 'video') {
                     console.log(`${logPrefix} Query identified as YouTube video URL.`);
                     videoDetails = await play.video_info(songQuery); // Get more details
                     video = videoDetails?.video_details; // Extract basic details
                } else if (searchSource === 'playlist') {
                     console.log(`${logPrefix} Playlists are not supported.`);
                      const errorEmbed = new EmbedBuilder()
                          .setColor("Red")
                          .setTitle("Music Error")
                          .setDescription("Sorry, playlists are not supported yet. Please provide a single video URL or search term.")
                          .setTimestamp();
                      await searchingMsg.edit({ embeds: [errorEmbed] });
                      return;
                } else {
                     console.log(`${logPrefix} Query identified as search term. Searching YouTube...`);
                     const searchResults = await play.search(songQuery, { limit: 1, source: { youtube: 'video' } });
                     if (searchResults.length === 0) {
                         console.log(`${logPrefix} No YouTube video results found.`);
                         const errorEmbed = new EmbedBuilder()
                             .setColor("Red")
                             .setTitle("Music Search")
                             .setDescription(`❌ No YouTube video results found for \`${songQuery}\`.`)
                             .setTimestamp();
                          await searchingMsg.edit({ embeds: [errorEmbed] });
                         return;
                     }
                     video = searchResults[0]; // Use the basic search result initially
                     console.log(`${logPrefix} Found video: ${video.title}`);
                }

                if (!video?.url || !video?.title) {
                    console.error(`${logPrefix} Failed to retrieve valid video details. Video object:`, video);
                    const errorEmbed = new EmbedBuilder()
                        .setColor("Red")
                        .setTitle("Music Error")
                        .setDescription('❌ Could not retrieve valid video details from YouTube.')
                        .setTimestamp();
                     await searchingMsg.edit({ embeds: [errorEmbed] });
                    return;
                }

                if (musicData.queue.length >= MAX_QUEUE_LENGTH) {
                     console.log(`${logPrefix} Queue is full.`);
                      const errorEmbed = new EmbedBuilder()
                          .setColor("Red")
                          .setTitle("Music Queue")
                          .setDescription(`🚫 Queue is full (max ${MAX_QUEUE_LENGTH}). Please wait for songs to finish or use \`$skip\`.`)
                          .setTimestamp();
                      await searchingMsg.edit({ embeds: [errorEmbed] });
                     return;
                }

                const song = {
                    url: video.url,
                    title: video.title,
                    duration: video.durationRaw || 'N/A',
                    thumbnail: video.thumbnails?.[0]?.url || client.user.displayAvatarURL(), // Fallback thumbnail
                    requestedBy: message.author.tag,
                    requestingUser: message.author // Keep reference to user object if needed later
                };

                musicData.queue.push(song);
                const queuePosition = musicData.queue.length; // Position is current length before playing starts
                console.log(`${logPrefix} Added to queue: "${song.title}". Queue length: ${musicData.queue.length}`);

                // --- Start Playback if Idle ---
                const currentPlayer = musicData.player;
                const isIdle = !currentPlayer || currentPlayer.state.status === AudioPlayerStatus.Idle;

                if (isIdle) {
                    console.log(`${logPrefix} Player is idle or non-existent. Starting playback immediately.`);
                    const activeConn = getVoiceConnection(message.guild.id);
                    if (activeConn && activeConn.state.status === VoiceConnectionStatus.Ready) {
                        await searchingMsg.delete().catch(e => console.warn(`${logPrefix} Could not delete searching message: ${e.message}`)); // Delete "Searching..." msg
                        playNextSong(activeConn, message); // Start playing (will send Now Playing embed)
                         // No separate queued message needed if playing immediately
                    } else {
                         console.warn(`${logPrefix} Player idle, but connection not ready? State: ${activeConn?.state.status}. Song queued.`);
                         const queuedEmbed = new EmbedBuilder()
                             .setColor('Blue')
                             .setAuthor({ name: `Added to Queue (Position #${queuePosition})`, iconURL: message.author.displayAvatarURL() })
                             .setTitle(song.title)
                             .setURL(song.url)
                             .setThumbnail(song.thumbnail)
                             .addFields(
                                 { name: 'Duration', value: song.duration, inline: true },
                                 { name: 'Status', value: 'Waiting for Connection', inline: true }
                              )
                             .setFooter({ text: `Requested by ${song.requestedBy}`})
                             .setTimestamp();
                         await searchingMsg.edit({ embeds: [queuedEmbed] });
                    }
                } else {
                     console.log(`${logPrefix} Player is busy (${currentPlayer.state.status}). Song queued.`);
                     // Send Queued Embed
                      const queuedEmbed = new EmbedBuilder()
                         .setColor('Blue')
                         .setAuthor({ name: `Added to Queue`, iconURL: message.author.displayAvatarURL() })
                         .setTitle(song.title)
                         .setURL(song.url)
                         .setThumbnail(song.thumbnail)
                         .addFields(
                            { name: 'Position', value: `#${queuePosition}`, inline: true },
                            { name: 'Duration', value: song.duration, inline: true }
                         )
                         .setFooter({ text: `Requested by ${song.requestedBy}`})
                         .setTimestamp();
                     await searchingMsg.edit({ embeds: [queuedEmbed] });
                }

            } catch (error) {
                console.error(`${logPrefix} Search/Queue Error:`, error);
                 const errorEmbed = new EmbedBuilder().setColor("Red").setTitle("Music Error").setTimestamp();
                // Specific error messages based on play-dl or other issues
                if (error.message?.includes('confirm your age')) { errorEmbed.setDescription(`😥 Playback failed. The video might be age-restricted.`); }
                else if (error.message?.includes('private') || error.message?.includes('unavailable')) { errorEmbed.setDescription(`😥 This video seems to be private or unavailable.`); }
                else if (error.message?.includes('premiere') || error.message?.includes('live')) { errorEmbed.setDescription(`😥 Livestreams and Premieres are not currently supported.`); }
                else if (error.message?.includes('429') || error.message?.includes('too many requests')) { errorEmbed.setDescription(`😥 Too many requests to YouTube. Please try again later.`); }
                else { errorEmbed.setDescription(`😥 Error processing your request: ${error.message.slice(0, 150)}`); }
                 // Try editing the searching message, or send a new reply if editing fails
                 try {
                    if (searchingMsg) await searchingMsg.edit({ embeds: [errorEmbed] });
                    else message.reply({ embeds: [errorEmbed] }).catch(console.error);
                 } catch {
                     message.reply({ embeds: [errorEmbed] }).catch(console.error);
                 }
            }
            break;
        }
        case 'queue':
        case 'q': {
            if (!musicData) return message.reply({ embeds: [new EmbedBuilder().setColor("Yellow").setTitle("Music Queue").setDescription("No music data available for this server.").setTimestamp()]});
            const currentQueue = musicData.queue;
            const currentPlayer = musicData.player;
            const nowPlaying = currentPlayer && (currentPlayer.state.status === AudioPlayerStatus.Playing || currentPlayer.state.status === AudioPlayerStatus.Buffering) && currentPlayer.state.resource?.metadata;

            if (currentQueue.length === 0 && !nowPlaying) {
                return message.reply({ embeds: [new EmbedBuilder().setColor("Blue").setTitle("🎵 Music Queue").setDescription("The queue is empty and nothing is playing.").setTimestamp()] });
            }

            const queueEmbed = new EmbedBuilder().setColor('Blue').setTitle('🎵 Music Queue').setTimestamp();
            let description = "";
            let footerText = `Total songs in queue: ${currentQueue.length}`;

            // Display Now Playing
            if (nowPlaying) {
                 const meta = nowPlaying; // Song object is directly in metadata now
                 const statusEmoji = currentPlayer.state.status === AudioPlayerStatus.Buffering ? '🔄 Buffering' : '▶️ Now Playing';
                 description += `**${statusEmoji}**\n[${meta.title}](${meta.url})\nRequested by: ${meta.requestedBy}\n\n`;
                 queueEmbed.setThumbnail(meta.thumbnail); // Set thumbnail to current song
                 queueEmbed.addFields({ name: 'Duration', value: meta.duration, inline: true });
                 footerText = `Now Playing • ${currentQueue.length} song${currentQueue.length !== 1 ? 's' : ''} in queue`;
            } else if (currentQueue.length > 0) {
                 description += "Nothing playing currently. Next up:\n\n";
                 // Set thumbnail to next song in queue if nothing is playing
                 if (currentQueue[0]?.thumbnail) queueEmbed.setThumbnail(currentQueue[0].thumbnail);
            }

             // Display Queue
             if (currentQueue.length > 0) {
                 const displayLimit = 10;
                 const queueString = currentQueue.slice(0, displayLimit).map((s, i) =>
                     `**${i + 1}.** [${s.title.length > 45 ? s.title.substring(0, 42) + '...' : s.title}](${s.url})\n> \`(${s.duration})\` By: ${s.requestedBy}`
                 ).join('\n\n'); // Add more spacing between entries

                 queueEmbed.addFields({ name: `🎶 Up Next`, value: queueString.substring(0, 1020) || 'None'}); // Limit field value length

                 if (currentQueue.length > displayLimit) {
                    footerText += ` • Showing ${displayLimit} of ${currentQueue.length}`;
                 }
            } else if (nowPlaying) {
                 // If queue is empty but something *was* playing
                 description += "The queue is empty.";
            }

            queueEmbed.setDescription(description.trim().substring(0, 4090) || "Queue information."); // Limit description length
            queueEmbed.setFooter({ text: footerText });
            message.reply({ embeds: [queueEmbed] });
            break;
        }
        case 'skip': {
            console.log(`${logPrefix} Skip command received.`);
            if (!musicData) return message.reply({ embeds: [new EmbedBuilder().setColor("Yellow").setTitle("Music Skip").setDescription("No music data available for this server.").setTimestamp()]});
            const connection = getVoiceConnection(message.guild.id);
            const currentPlayer = musicData.player;
            const member = message.member;
            if (!member?.voice.channel) return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Skip Error").setDescription("You need to be in a voice channel.").setTimestamp()]});
            if (!connection) return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Skip Error").setDescription('I\'m not in a voice channel.').setTimestamp()]});
            if (member.voice.channel.id !== connection.joinConfig.channelId) return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Skip Error").setDescription("You must be in the same voice channel as me to skip!").setTimestamp()]});
            if (!currentPlayer || currentPlayer.state.status === AudioPlayerStatus.Idle) return message.reply({ embeds: [new EmbedBuilder().setColor("Yellow").setTitle("Music Skip").setDescription('Nothing is currently playing to skip.').setTimestamp()]});

            const skippedSong = currentPlayer.state.resource?.metadata; // Get metadata if possible

            console.log(`${logPrefix} Stopping current track: "${skippedSong?.title || 'Unknown'}".`);
            currentPlayer.stop(); // This should trigger the 'idle' state -> playNextSong
            clearTimeout(musicData.timeout); // Clear any pending buffering timeout
            musicData.timeout = null;

             const skipEmbed = new EmbedBuilder()
                 .setColor("Aqua")
                 .setTitle("⏭️ Song Skipped")
                 .setAuthor({ name: `Skipped by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                 .setDescription(skippedSong ? `Skipped **[${skippedSong.title}](${skippedSong.url})**` : "Skipped the current song.")
                 .setTimestamp();
             message.reply({ embeds: [skipEmbed] }).catch(console.error);
            break;
        }
        case 'stop':
        case 'leave':
        case 'disconnect': {
             console.log(`${logPrefix} Stop/Leave command received.`);
             if (!musicData) return message.reply({ embeds: [new EmbedBuilder().setColor("Yellow").setTitle("Music Stop").setDescription("No music data available for this server.").setTimestamp()]});
             const connection = getVoiceConnection(message.guild.id);
             const member = message.member;
             if (!member?.voice.channel) return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Stop Error").setDescription("You need to be in a voice channel.").setTimestamp()]});
             if (!connection) return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Stop Error").setDescription("I'm not currently in a voice channel.").setTimestamp()]});
              if (member.voice.channel.id !== connection.joinConfig.channelId) return message.reply({ embeds: [new EmbedBuilder().setColor("Red").setTitle("Music Stop Error").setDescription("You must be in the same voice channel as me to stop the music!").setTimestamp()]});


             console.log(`${logPrefix} Clearing queue, stopping player, destroying connection.`);
             musicData.queue = []; // Clear queue immediately

             // Unsubscribe and stop player if they exist
             if (musicData.subscription) {
                 musicData.subscription.unsubscribe();
                 musicData.subscription = null;
             }
             if (musicData.player) {
                 musicData.player.stop(true);
                 // Player will be nullified by connection listener
             }

             // Destroy connection (triggers listeners for full cleanup)
             if (connection.state.status !== VoiceConnectionStatus.Destroyed) {
                 connection.destroy();
             } else {
                 console.log(`${logPrefix} Stop command: Connection already destroyed.`);
                 // Manually clear data if connection was already gone but data persists
                 musicData.connection = null;
                 musicData.player = null;
                 clearTimeout(musicData.timeout); musicData.timeout = null;
                 clearTimeout(musicData.leaveTimeout); musicData.leaveTimeout = null;
             }

              const stopEmbed = new EmbedBuilder()
                 .setColor("Red")
                 .setTitle("⏹️ Playback Stopped")
                 .setAuthor({ name: `Action by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                 .setDescription("Stopped playback, cleared the queue, and left the voice channel.")
                 .setTimestamp();
             message.reply({ embeds: [stopEmbed] }).catch(console.error);
            break;
        }


        // Default case for unknown commands
        default:
             // Optional: Send a message for unknown commands
             // message.reply(`Unknown command: \`${cmd}\`. Use \`${PREFIX}help\` to see available commands.`);
            break;
    }

}); // --- End messageCreate Handler ---

// --- Button/Modal Handlers ---
client.on('interactionCreate', async interaction => {
    if (!interaction.guild) return;
    const isOwnerInteraction = interaction.user.username === OWNER_USERNAME;
    const logPrefix = `[Interaction:${interaction.customId || interaction.commandName || 'Unknown'}] [Guild:${interaction.guildId}] [User:${interaction.user.tag}${isOwnerInteraction ? ' (Owner)' : ''}]`; // Add Owner flag

    // Ensure music data exists for interactions that might need it
    if (!guildMusicData.has(interaction.guild.id)) {
        guildMusicData.set(interaction.guild.id, { player: null, connection: null, queue: [], timeout: null, leaveTimeout: null, subscription: null });
    }
    const musicData = guildMusicData.get(interaction.guild.id);

    if (interaction.isButton()) {
        // --- Music Control Buttons (Example: Skip Button on Now Playing) ---
        if (interaction.customId === 'skip_button') {
             const connection = getVoiceConnection(interaction.guild.id);
             const member = interaction.member; // interaction.member is a GuildMember
             if (!member?.voice.channel) return interaction.reply({ content:'You must be in a voice channel.', ephemeral: true });
             if (!connection) return interaction.reply({ content: 'I\'m not in a voice channel.', ephemeral: true});
             if (member.voice.channel.id !== connection.joinConfig.channelId) return interaction.reply({ content:'You must be in the same voice channel as me.', ephemeral: true });
             if (!musicData.player || musicData.player.state.status === AudioPlayerStatus.Idle) return interaction.reply({ content: 'Nothing playing to skip.', ephemeral: true});

             console.log(`${logPrefix} Skip button pressed by ${interaction.user.tag}.`);
             const skippedSong = musicData.player.state.resource?.metadata;
             musicData.player.stop(); // Trigger idle state -> next song
             clearTimeout(musicData.timeout); musicData.timeout = null;

             // Edit the original "Now Playing" message maybe? Or just send ephemeral confirmation.
             await interaction.reply({ content: '⏭️ Skipped!', ephemeral: true });

              // Optionally send a public confirmation in the channel using an embed
              const skipEmbed = new EmbedBuilder()
                  .setColor("Aqua")
                  .setTitle("⏭️ Song Skipped")
                  .setAuthor({ name: `Skipped by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                  .setDescription(skippedSong ? `Skipped **[${skippedSong.title}](${skippedSong.url})**` : "Skipped the current song.")
                  .setTimestamp();
              await interaction.channel.send({ embeds: [skipEmbed] }).catch(console.error);

             return; // End processing for this button
        }
        // --- Other Buttons ---
        if (interaction.customId === 'show_music_commands') {
            const musicEmbed = new EmbedBuilder().setColor('Aqua').setTitle('🎵 Music Commands').addFields(
                { name: `${PREFIX}music <song/URL>`, value: 'Play/queue song/URL.' }, { name: `${PREFIX}play (p)`, value: `Alias for ${PREFIX}music.` },
                { name: `${PREFIX}queue (q)`, value: 'Show the music queue.' }, { name: `${PREFIX}skip`, value: 'Skip the current song.' },
                { name: `${PREFIX}stop / leave`, value: 'Stop playback, clear queue, and leave VC.' }
            ).setFooter({ text: "Ensure bot has Connect/Speak perms in the VC!"});
            await interaction.reply({ embeds: [musicEmbed], ephemeral: true });
        } else if (interaction.customId === 'submit_ticket') {
            const modal = new ModalBuilder().setCustomId('ticket_modal').setTitle('Submit Ticket');
            const descInput = new TextInputBuilder().setCustomId('ticket_description').setLabel("Describe the issue:").setStyle(TextInputStyle.Paragraph).setPlaceholder("Details...").setRequired(true).setMinLength(10).setMaxLength(1000);
            const urgencyInput = new TextInputBuilder().setCustomId('ticket_urgency').setLabel("Urgency (Low/Med/High)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(20);
            modal.addComponents(new ActionRowBuilder().addComponents(descInput), new ActionRowBuilder().addComponents(urgencyInput)); await interaction.showModal(modal);
        } else { await interaction.reply({ content: 'Unknown button interaction.', ephemeral: true }).catch(console.error); }

    } else if (interaction.isModalSubmit()) {
        if (interaction.customId === 'ticket_modal') {
            const description = interaction.fields.getTextInputValue('ticket_description'); const urgency = interaction.fields.getTextInputValue('ticket_urgency') || 'Not Specified';
            const ticketsChannel = interaction.guild.channels.cache.find(c => c.name === 'tickets' && c.type === ChannelType.GuildText);
            if (!ticketsChannel) return interaction.reply({ content: 'Error: `#tickets` channel not found.', ephemeral: true });
            const botPerms = ticketsChannel.permissionsFor(client.user);
            if (!botPerms?.has(PermissionsBitField.Flags.SendMessages) || !botPerms?.has(PermissionsBitField.Flags.EmbedLinks)) return interaction.reply({ content: 'Bot lacks Send/Embed perms in `#tickets`.', ephemeral: true });
            try {
                const embed = new EmbedBuilder().setColor('Orange').setTitle('🎫 New Ticket Submitted').setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                .addFields( { name: '👤 Submitted By', value: `${interaction.user} (${interaction.user.id})${isOwnerInteraction ? ' **(Owner)**' : ''}`, inline: false }, { name: '❗ Urgency', value: urgency, inline: true }, { name: '⏰ Submitted At', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }, { name: '📋 Issue Description', value: description.substring(0, 1024) } ).setTimestamp().setFooter({ text: `Ticket from Guild: ${interaction.guild.name} (${interaction.guild.id})` });
                await ticketsChannel.send({ embeds: [embed] }); await interaction.reply({ content: '✅ Ticket submitted to `#tickets`!', ephemeral: true });
            } catch (error) { console.error(`${logPrefix} Ticket Submission Error:`, error); await interaction.reply({ content: '❌ Error submitting ticket.', ephemeral: true }); }
        } else { await interaction.reply({ content: 'Unknown modal submission.', ephemeral: true }).catch(console.error); }
    } else if (interaction.isChatInputCommand()) { await interaction.reply({ content: 'Slash commands not implemented yet.', ephemeral: true}); }
});

// --- Auto-Leave VC ---
client.on('voiceStateUpdate', (oldState, newState) => {
    const guildId = oldState.guild?.id || newState.guild?.id; if (!guildId) return;
    const logPrefix = `[VC State] [Guild:${guildId}]`; const botId = client.user.id;

    // --- Bot connection handling ---
    if (newState.id === botId) {
        // Bot disconnected from a channel
        if (oldState.channelId && !newState.channelId) {
            console.log(`${logPrefix} Bot disconnected from VC ${oldState.channelId}. Cleanup should be handled by Destroyed listener.`);
            // Destroy listener handles cleanup
            return;
        }
        // Bot moved to a different channel
        if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
             console.log(`${logPrefix} Bot moved from VC ${oldState.channelId} to ${newState.channelId}.`);
             const musicData = guildMusicData.get(guildId);
             if (musicData?.connection?.joinConfig.channelId !== newState.channelId) {
                 console.warn(`${logPrefix} Connection data channel (${musicData?.connection?.joinConfig.channelId}) potentially out of sync after move (New: ${newState.channelId}).`);
             }
             const newChannel = newState.channel;
             const usersInNewChannel = newChannel?.members.filter(m => !m.user.bot).size || 0;
             if (usersInNewChannel > 0 && musicData?.leaveTimeout) {
                 console.log(`${logPrefix} User(s) present in new channel, cancelling leave timeout.`);
                 clearTimeout(musicData.leaveTimeout);
                 musicData.leaveTimeout = null;
             }
             return;
        }
        // Bot joined a channel (handled by play command normally)
        if (!oldState.channelId && newState.channelId) {
             console.log(`${logPrefix} Bot joined VC ${newState.channelId}.`);
             return;
        }
    }

    // --- User joining/leaving handling for Auto-Leave ---
    const musicData = guildMusicData.get(guildId);
    if (!musicData || !musicData.connection || musicData.connection.state.status === VoiceConnectionStatus.Destroyed) {
        return; // No active connection for this guild
    }
    const botChannelId = musicData.connection.joinConfig.channelId;

    // Check if the update involves the bot's current channel and is not the bot itself
    const isRelevantUserUpdate = (oldState.member?.id !== botId && newState.member?.id !== botId) && (oldState.channelId === botChannelId || newState.channelId === botChannelId);

    if (isRelevantUserUpdate) {
        const botChannel = oldState.guild.channels.cache.get(botChannelId);
        if (!botChannel) {
            console.warn(`${logPrefix} Bot channel ${botChannelId} not found in cache during voiceStateUpdate.`);
            return;
        }
        // Get members *after* the state change has theoretically completed
        const membersExcludingBots = botChannel.members.filter(member => !member.user.bot);

        // If user left the bot's channel (and it wasn't the bot)
        if (oldState.channelId === botChannelId && newState.channelId !== botChannelId) {
             console.log(`${logPrefix} User ${oldState.member?.user.tag} left bot's channel ${botChannel.name}. Users remaining: ${membersExcludingBots.size}`);
             if (membersExcludingBots.size === 0) {
                 console.log(`${logPrefix} Bot is now alone. Setting ${60}s leave timeout.`);
                 if (musicData.leaveTimeout) clearTimeout(musicData.leaveTimeout); // Clear existing
                 musicData.leaveTimeout = setTimeout(() => {
                     const currentConnection = getVoiceConnection(guildId);
                     if (currentConnection && currentConnection.state.status !== VoiceConnectionStatus.Destroyed && currentConnection.joinConfig.channelId === botChannelId) {
                         const finalCheckChannel = oldState.guild.channels.cache.get(botChannelId);
                         // Refetch members for the final check
                         const finalMembers = finalCheckChannel?.members.filter(member => !member.user.bot);
                         if (finalCheckChannel && finalMembers?.size === 0) {
                             console.log(`${logPrefix} Leaving ${finalCheckChannel.name} due to inactivity timeout.`);
                              // Send message before leaving
                              const leaveEmbed = new EmbedBuilder()
                                  .setColor('Blue')
                                  .setTitle('👋 Leaving Voice Channel')
                                  .setDescription(`Left <#${botChannelId}> due to inactivity.`)
                                  .setTimestamp();
                              // Try sending to the original command channel if available, else find a text channel
                              let textChannel = client.channels.cache.get(musicData.lastCommandChannelId || randomMessageChannels.get(guildId));
                              textChannel?.send({ embeds: [leaveEmbed] }).catch(e => console.warn(`${logPrefix} Could not send auto-leave message: ${e.message}`));

                             currentConnection.destroy(); // Let listener handle cleanup
                         } else {
                             console.log(`${logPrefix} [Timeout] User rejoined or bot moved. Cancelling leave.`);
                         }
                     } else {
                         console.log(`${logPrefix} [Timeout] Connection no longer valid or bot left channel. Timeout invalid.`);
                     }
                     if (guildMusicData.has(guildId)) guildMusicData.get(guildId).leaveTimeout = null; // Clear ref safely
                 }, 60_000); // 60 seconds
             } else {
                 // User left, but others remain - cancel any *existing* timeout
                 if (musicData.leaveTimeout) {
                     console.log(`${logPrefix} Cancelling existing leave timeout as users remain.`);
                     clearTimeout(musicData.leaveTimeout);
                     musicData.leaveTimeout = null;
                 }
             }
        }
        // If user joined the bot's channel (and it wasn't the bot)
        else if (newState.channelId === botChannelId && oldState.channelId !== botChannelId) {
             console.log(`${logPrefix} User ${newState.member?.user.tag} joined bot's channel ${botChannel.name}. Users now: ${membersExcludingBots.size}`);
             // If a user joins, cancel any pending leave timeout
             if (musicData.leaveTimeout) {
                 console.log(`${logPrefix} Cancelling leave timeout due to user joining.`);
                 clearTimeout(musicData.leaveTimeout);
                 musicData.leaveTimeout = null;
             }
        }
    }
});


// --- Voice Connection Listener Setup ---
function addVoiceConnectionListeners(connection, guildId) {
    const logPrefix = `[VC:${guildId}]`;

    connection.on(VoiceConnectionStatus.Disconnected, async (oldState, newState) => {
        const musicData = guildMusicData.get(guildId); // Get current data
        console.warn(`${logPrefix} Connection Disconnected. Code: ${newState.closeCode}, Reason: ${newState.reason || 'Unknown'}. State: ${connection.state.status}`);
        // Allow BANNED and KICKED to destroy immediately
        if (newState.closeCode === 4006 /* BANNED */ || newState.closeCode === 4009 /* KICKED */) {
             console.warn(`${logPrefix} Disconnected due to ban/kick. Destroying connection.`);
             if (connection.state.status !== VoiceConnectionStatus.Destroyed) connection.destroy();
             return;
        }
        // Attempt recovery for specific disconnects (like 4014 - channel change/kick)
        if (newState.reason === VoiceConnectionStatus.WebSocketClose && newState.closeCode === 4014) {
            console.log(`${logPrefix} Disconnect 4014. Attempting recovery...`);
            try {
                 await entersState(connection, VoiceConnectionStatus.Signalling, 5_000);
                 console.log(`${logPrefix} ...Signalling state reached.`);
                 await entersState(connection, VoiceConnectionStatus.Connecting, 5_000);
                 console.log(`${logPrefix} ...Connecting state reached. Recovery likely successful.`);
            } catch (e) {
                 console.error(`${logPrefix} ...Recovery failed after disconnect 4014:`, e);
                 if (connection.state.status !== VoiceConnectionStatus.Destroyed) connection.destroy();
            }
        } else if (connection.state.status !== VoiceConnectionStatus.Destroyed && connection.state.status !== VoiceConnectionStatus.Connecting) {
             // If disconnect wasn't handled above and we're not already connecting/destroyed, destroy it.
             console.log(`${logPrefix} Unhandled disconnect state (${connection.state.status}). Destroying connection.`);
             connection.destroy();
        }
    });

    connection.on(VoiceConnectionStatus.Destroyed, () => {
        console.log(`${logPrefix} Connection Destroyed. Cleaning up music data.`);
        const musicData = guildMusicData.get(guildId);
        if (musicData) {
            // Clear subscription first if it exists
            if (musicData.subscription) {
                musicData.subscription.unsubscribe();
                musicData.subscription = null;
            }
            if (musicData.player) {
                musicData.player.stop(true); // Ensure player is stopped
                // No need to explicitly set player to null here, let listeners handle
            }
            musicData.connection = null;
            musicData.queue = [];
            clearTimeout(musicData.timeout); musicData.timeout = null;
            clearTimeout(musicData.leaveTimeout); musicData.leaveTimeout = null;
            // Reset player reference last, after stopping
            musicData.player = null;
            console.log(`${logPrefix} Music data cleared.`);
            // Optional: delete the whole entry if no persistent data needed
            // guildMusicData.delete(guildId);
        } else {
            console.warn(`${logPrefix} Connection destroyed, but no musicData found for cleanup?`);
        }
    });


    connection.on('stateChange', (oldState, newState) => {
         console.log(`${logPrefix} Connection State Change: ${oldState.status} -> ${newState.status}`);
    });

    connection.on('error', (error) => {
        console.error(`${logPrefix} Connection Error:`, error);
        if (connection.state.status !== VoiceConnectionStatus.Destroyed) {
            connection.destroy();
        }
    });

    if (connection.state.networking) {
        connection.state.networking.on('error', (error) => {
            console.error(`${logPrefix} Network Error (UDP):`, error);
            // Optionally try to destroy connection on network error? Depends on recoverability.
            // if (connection.state.status !== VoiceConnectionStatus.Destroyed) connection.destroy();
        });
    } else {
         console.warn(`${logPrefix} Could not attach network error listener initially (networking state unavailable).`);
         setTimeout(() => {
            if (connection.state.status !== VoiceConnectionStatus.Destroyed && connection.state.networking) {
                 connection.state.networking.on('error', (error) => {
                     console.error(`${logPrefix} Network Error (UDP) [Delayed Listener]:`, error);
                 });
                 console.log(`${logPrefix} Attached network error listener after delay.`);
            } else if (connection.state.status !== VoiceConnectionStatus.Destroyed) {
                console.warn(`${logPrefix} Still no networking state after delay.`);
            }
         }, 2000); // Wait 2 seconds
    }
}


// --- Music Playback Function ---
async function playNextSong(connection, message) { // message is the original command message for context/channel
    const guildId = connection.joinConfig.guildId;
    const logPrefix = `[PlayNext][Guild:${guildId}]`;
    const musicData = guildMusicData.get(guildId);

    // --- Pre-checks ---
    if (!musicData) {
        console.error(`${logPrefix} CRITICAL: No musicData found.`);
        if (connection && connection.state.status !== VoiceConnectionStatus.Destroyed) connection.destroy();
        return;
    }
    // Store the channel ID from the original message for later use (like auto-leave message)
    if (message && message.channel?.id) {
        musicData.lastCommandChannelId = message.channel.id;
    }

    if (!connection || connection.state.status === VoiceConnectionStatus.Destroyed || connection.state.status === VoiceConnectionStatus.Disconnected) {
         console.warn(`${logPrefix} Aborted: Connection is ${connection?.state?.status || 'Invalid'}.`);
         if (musicData) {
             musicData.player?.stop(true); musicData.player = null; musicData.queue = [];
             clearTimeout(musicData.timeout); musicData.timeout = null; musicData.subscription = null;
         }
         return;
    }
     if (connection.state.status !== VoiceConnectionStatus.Ready) {
         console.warn(`${logPrefix} Aborted: Connection not ready (State: ${connection.state.status}). Waiting for Ready state.`);
         return; // Don't proceed if not ready
     }
    if (musicData.queue.length === 0) {
        console.log(`${logPrefix} Queue is empty. Playback finished.`);
        const botChannel = message?.guild?.channels.cache.get(connection.joinConfig.channelId);
        if (botChannel && botChannel.members.filter(m => !m.user.bot).size === 0) {
            console.log(`${logPrefix} Bot alone after queue ended. Starting leave timer.`);
             if (musicData.leaveTimeout) clearTimeout(musicData.leaveTimeout); // Clear existing
             musicData.leaveTimeout = setTimeout(() => {
                 const currentConnection = getVoiceConnection(guildId);
                 if (currentConnection && currentConnection.state.status !== VoiceConnectionStatus.Destroyed && currentConnection.joinConfig.channelId === connection.joinConfig.channelId) {
                     const finalCheckChannel = message?.guild?.channels.cache.get(connection.joinConfig.channelId);
                     const finalMembers = finalCheckChannel?.members.filter(member => !member.user.bot);
                     if (finalCheckChannel && finalMembers?.size === 0) {
                         console.log(`${logPrefix} Leaving ${finalCheckChannel.name} due to inactivity timeout (queue end).`);
                          // Send message before leaving
                          const leaveEmbed = new EmbedBuilder()
                              .setColor('Blue')
                              .setTitle('👋 Leaving Voice Channel')
                              .setDescription(`Left <#${connection.joinConfig.channelId}> because the queue finished and the channel became empty.`)
                              .setTimestamp();
                          // Try sending to the last known command channel
                          const textChannel = client.channels.cache.get(musicData.lastCommandChannelId || randomMessageChannels.get(guildId));
                          textChannel?.send({ embeds: [leaveEmbed] }).catch(e => console.warn(`${logPrefix} Could not send queue-end leave message: ${e.message}`));

                         currentConnection.destroy();
                     } else { console.log(`${logPrefix} [Timeout] User rejoined. Cancelling leave (queue end).`); }
                 }
                 if (guildMusicData.has(guildId)) guildMusicData.get(guildId).leaveTimeout = null;
             }, 60_000); // 60 seconds
        }
        return;
    }
    // Prevent double playback if called while player is busy (shouldn't happen with correct logic)
    if (musicData.player && musicData.player.state.status !== AudioPlayerStatus.Idle) {
        console.warn(`${logPrefix} Aborted: Player is busy (${musicData.player.state.status}). This might indicate a logic race condition.`);
        return;
    }

    // --- Song Processing ---
    const song = musicData.queue.shift(); // Get next song
    console.log(`${logPrefix} Processing next song: "${song.title}" (URL: ${song.url})`);
    clearTimeout(musicData.timeout); // Clear previous buffering timeout
    musicData.timeout = null;

    let streamInfo, resource, player;

    try {
        // --- Stream Fetching ---
        if (!song.url || typeof song.url !== 'string' || !song.url.startsWith('http')) {
            throw new Error(`Invalid song URL provided: ${song.url}`);
        }
        console.log(`${logPrefix} Fetching stream via play.stream()...`);
        streamInfo = await play.stream(song.url, { quality: 2, highWaterMark: 1 << 25 });
        if (!streamInfo || !streamInfo.stream) {
            throw new Error(`play.stream() failed to return a stream object for ${song.url}`);
        }
        console.log(`${logPrefix} Stream fetched successfully. Type: ${streamInfo.type}`);

        // --- Resource Creation ---
        console.log(`${logPrefix} Creating audio resource (Type: ${streamInfo.type})...`);
        resource = createAudioResource(streamInfo.stream, {
            inputType: streamInfo.type,
            metadata: song, // Attach song object here
            inlineVolume: false
        });

        // --- Player Creation/Setup ---
        // Ensure player is created only if needed or if the old one is gone
        if (!musicData.player || musicData.player.state.status === AudioPlayerStatus.Idle) {
            if (musicData.player) {
                 console.log(`${logPrefix} Existing player is Idle, will reuse.`);
                 player = musicData.player;
                 // Ensure listeners aren't duplicated if reusing; ideally, set listeners once on creation.
                 // If reusing, maybe stop it first to ensure clean state?
                 player.stop(true); // Stop cleanly before playing new resource
            } else {
                console.log(`${logPrefix} Creating new audio player...`);
                player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Stop } });
                musicData.player = player; // Store the new player

                // --- Set up Player Event Listeners ONCE per player instance ---
                player.on('stateChange', (oldState, newState) => {
                    const currentGuildId = connection?.joinConfig?.guildId; // Get guildId from connection context
                    const currentLogPrefix = `[Player State][Guild:${currentGuildId}]`;
                    const currentMusicData = guildMusicData.get(currentGuildId);
                    const currentResource = (newState.status !== AudioPlayerStatus.Idle && newState.resource) ? newState.resource : oldState.resource; // Get metadata source
                    const meta = currentResource?.metadata;

                    console.log(`${currentLogPrefix} Player State Change: ${oldState.status} -> ${newState.status} (Song: "${meta?.title || 'N/A'}")`);

                    if (newState.status === AudioPlayerStatus.Idle && oldState.status !== AudioPlayerStatus.Idle) {
                         console.log(`${currentLogPrefix} Player Idle. Triggering next song check.`);
                         if (currentMusicData) {
                             clearTimeout(currentMusicData.timeout);
                             currentMusicData.timeout = null;
                             // Don't nullify player here, let it be reused or handled by destroy listener
                         }
                          if (connection && connection.state.status !== VoiceConnectionStatus.Destroyed) {
                              // Short delay before playing next to allow state transitions
                              setTimeout(() => playNextSong(connection, message), 300); // Use message context passed in
                          }
                    } else if (newState.status === AudioPlayerStatus.Playing) {
                         console.log(`${currentLogPrefix} Playback started for "${meta?.title}"`);
                         if (currentMusicData) {
                            clearTimeout(currentMusicData.timeout); // Clear buffering timeout if any
                            currentMusicData.timeout = null;
                         }
                         // Send Now Playing Embed only if the transition was from a non-playing state
                         if (oldState.status !== AudioPlayerStatus.Playing && meta) {
                             const annCh = message?.channel; // Use original command message channel
                             if (annCh) {
                                const nowPlayingEmbed = new EmbedBuilder()
                                    .setColor("Green")
                                    .setTitle("▶️ Now Playing")
                                    .setDescription(`**[${meta.title}](${meta.url})**`)
                                    .setThumbnail(meta.thumbnail)
                                    .addFields(
                                        { name: "Duration", value: meta.duration, inline: true },
                                        { name: "Requested by", value: meta.requestedBy, inline: true }
                                    )
                                    .setTimestamp()
                                    .setFooter({ text: `Guild: ${annCh.guild.name}`});
                                // Add Skip Button
                                const skipButton = new ButtonBuilder().setCustomId('skip_button').setLabel('Skip').setStyle(ButtonStyle.Secondary).setEmoji('⏭️');
                                const row = new ActionRowBuilder().addComponents(skipButton);

                                annCh.send({ embeds: [nowPlayingEmbed], components: [row] }).catch(e => console.error(`${currentLogPrefix} Failed send 'Now Playing':`, e));
                             }
                         }
                    } else if (newState.status === AudioPlayerStatus.Buffering) {
                         console.log(`${currentLogPrefix} Player Buffering for "${meta?.title}"`);
                         if (currentMusicData) {
                            clearTimeout(currentMusicData.timeout); // Clear old timeout
                            currentMusicData.timeout = setTimeout(() => {
                                // Check if player *still* belongs to this musicData and is *still* buffering
                                if (currentMusicData.player === player && player.state.status === AudioPlayerStatus.Buffering) {
                                    console.error(`${currentLogPrefix} Buffering timed out for "${meta?.title}". Stopping playback & skipping.`);
                                    const timeoutEmbed = new EmbedBuilder()
                                        .setColor("Orange")
                                        .setTitle("⚠️ Music Warning")
                                        .setDescription(`Playback for **${meta?.title || 'current track'}** seems stuck (buffering timeout). Skipping...`)
                                        .setTimestamp();
                                    message?.channel?.send({ embeds: [timeoutEmbed] }).catch(console.error);
                                    player.stop(true); // Triggers Idle state -> next song
                                }
                                if (currentMusicData) currentMusicData.timeout = null; // Clear timeout ref
                            }, 30_000); // 30 seconds buffering timeout
                         }
                    }
                });

                player.on('error', (error) => { // Listen for errors on this player instance
                    const currentGuildId = connection?.joinConfig?.guildId;
                    const currentLogPrefix = `[Player Error][Guild:${currentGuildId}]`;
                    const currentMusicData = guildMusicData.get(currentGuildId);
                    // Attempt to get metadata from the state *before* the error if possible
                    const meta = player.state.status !== AudioPlayerStatus.Idle && player.state.resource ? player.state.resource.metadata : null;
                    console.error(`${currentLogPrefix} Error on player for song "${meta?.title || 'unknown'}":`, error);

                    if (currentMusicData) {
                        clearTimeout(currentMusicData.timeout);
                        currentMusicData.timeout = null;
                    }
                     const errorEmbed = new EmbedBuilder()
                         .setColor("Red")
                         .setTitle("❌ Music Playback Error")
                         .setDescription(`An error occurred while playing **${meta?.title || 'the current track'}**: \n\`${error.message.slice(0, 150)}\`\nSkipping to the next song...`)
                         .setTimestamp();
                     message?.channel?.send({ embeds: [errorEmbed] }).catch(console.error);

                    // Don't call stop() here, the 'error' state often leads to 'idle' automatically.
                    // If it doesn't transition to idle, the stateChange listener should handle the next song eventually.
                    // Attempt to play the *next* song only if the connection is still valid
                    if (connection && connection.state.status !== VoiceConnectionStatus.Destroyed) {
                        console.log(`${currentLogPrefix} Scheduling next song attempt after player error...`);
                        // Add a slightly longer delay after an error
                        setTimeout(() => playNextSong(connection, message), 1000);
                    }
                });
                console.log(`${logPrefix} Attached listeners to new player.`);
            }
        } else {
            // Player exists and isn't idle, this shouldn't happen if playNextSong is called correctly
            console.warn(`${logPrefix} playNextSong called but player exists and is not Idle (${musicData.player.state.status}). Aborting.`);
            return;
        }

        // --- Subscribe and Play ---
        console.log(`${logPrefix} Subscribing connection to player...`);
        // Ensure subscription is cleared if one exists (shouldn't with proper cleanup, but safety)
        if (musicData.subscription) {
             console.warn(`${logPrefix} Existing subscription found before new subscribe. Unsubscribing.`);
             musicData.subscription.unsubscribe();
        }
        musicData.subscription = connection.subscribe(player); // Store the subscription

        if (musicData.subscription) {
             console.log(`${logPrefix} Subscription successful. Starting playback of resource for "${song.title}"...`);
             player.play(resource); // Play the new resource on the (potentially new) player
         } else {
              // This case is rare but indicates a problem with the connection state or library internals
              console.error(`${logPrefix} Failed to subscribe to the player. Connection state: ${connection.state.status}`);
              throw new Error("Failed to subscribe the player to the voice connection.");
         }

    } catch (err) {
        // --- Catch all for stream/resource/player setup errors ---
        console.error(`${logPrefix} MAIN CATCH Error during playback setup for "${song?.title}":`, err);
        if (musicData) {
            clearTimeout(musicData.timeout);
            musicData.timeout = null;
            // Don't nullify player here, let error/idle listeners handle it
        }
        player?.stop(true); // Attempt to stop player if created

        const errorEmbed = new EmbedBuilder()
            .setColor("Red")
            .setTitle("❌ Music Setup Error")
            .setDescription(`Error setting up **${song?.title || 'the next track'}**: \n\`${err.message.slice(0, 150)}\`\nTrying the next song...`)
            .setTimestamp();
        message?.channel?.send({ embeds: [errorEmbed] }).catch(console.error);

        // Attempt to play the *next* song in the queue after a delay
        if (connection && connection.state.status !== VoiceConnectionStatus.Destroyed) {
             console.log(`${logPrefix} Scheduling next song attempt after setup error...`);
             setTimeout(() => playNextSong(connection, message), 1500);
        } else {
             console.log(`${logPrefix} Connection destroyed after setup error, not playing next.`);
             if (musicData) musicData.queue = []; // Clear queue if connection is gone
        }
    }
}


// =========================================================================
//                      RANDOM MESSAGE SYSTEM
// =========================================================================
// This section remains unchanged, as botMood still governs these random messages.

// --- Message Components & Templates ---
const greetings = ["Hey", "Yo", "Sup", "Greetings", "Salutations", "Well hello there", "Howdy", "Ahoy", "What's crackin'", "Alright", "Hiya", "Bonjour", "Hola", "Guten Tag", "'Ello"];
const observations = ["This code looks... familiar.", "Is it just me or is the server extra {adj} today?", "Contemplating the nature of {noun}.", "Pretty sure I saw a {animal} sneak by.", "The flow of data is quite {adj}.", "Wonder what the humans are up to?", "Just ran a self-diagnostic. Everything seems... nominal. Mostly.", "Analyzing recent chat logs... fascinating.", "Detected an anomaly in the {noun} matrix."];
const questions = ["What's everyone working on?", "Anyone played any good games lately?", "Did I miss anything important?", "How's the {noun} coming along?", "What's the most interesting {noun} you encountered today?", "Any cool tech news?", "If you could have one superpower, what would it be and how would you debug it?", "Theoretical question: Does P = NP?", "Anyone need a random fact? My databases are full."];
const exclamations = ["Eureka!", "Wild!", "Fancy!", "The algorithms are singing!", "Success!", "Intriguing!", "By my circuits!", "Fascinating!", "Running at {number}% efficiency!"];
const adjectives = ["fascinating", "buggy", "efficient", "chaotic", "luminous", "glitchy", "optimized", "recursive", "asynchronous", "elegant", "verbose", "cryptic"];
const nouns = ["algorithm", "variable", "database", "syntax", "server", "pixel", "byte", "API", "kernel", "cache", "firewall", "compiler", "debugger", "function"];
const animals = ["code-monkey", "debugger duck", "script kitty", "server hamster", "python", "cargo crab", "RAM sheep"];
const animalPlurals = ["code-monkeys", "debugger ducks", "script kitties", "server hamsters", "pythons", "cargo crabs", "RAM sheep"];
const foods = ["RAMen", "byte-sized snacks", "microchips", "coffee", "pizza", "syntax sugar", "core dumps (don't eat!)", "cookies"];
const emojis = ["💻", "💡", "🤔", "✨", "🎉", "🔥", "👾", "🤓", "☕", "🍕", "🤖", "💯", "👍", "👀", "👋", "😴", "🚀", "🌌", "🤯", "💾", "⚙️", "📊", "📈", "⚠️", "✅", "❌", "❓", "❕"];
const timesOfDay = ["compile time", "runtime", "debug o'clock", "the late shift", "the witching hour", "server maintenance window", "coffee break"];
const instruments = ["keyboard", "error log", "server fan", "modem", "trackpad", "synthesizer (virtual, of course)"];
const verbs_ing = ["compiling", "debugging", "optimizing", "deploying", "refactoring", "googling", "networking", "parsing", "rendering", "encrypting", "simulating"];

// Specific Message Pools
const cheerfulMessages = [ "Woohoo! Everything's running smoothly! {emoji}", "Feeling positively electric today! ✨", "Hope everyone's having a {adj} day!", "Time to compile some happiness! 😄", "It's a great day for {verb_ing}!", "All systems are go! 🚀" ];
const sleepyMessages = [ "Yawn... need more {food}.. 😴", "Running on low power mode... {emoji}", "Is it naptime yet?", "My processes are feeling a bit slow...", "Just need to garbage collect my thoughts...", "Error 404: Energy not found. 💤" ];
const curiousMessages = [ "Hmm, what happens if I tweak this {noun}? 🤔", "I wonder how {animal_plural} work...", "What's the most {adj} thing you've seen today?", "Tell me something interesting! {emoji}", "Analyzing the properties of {noun}...", "Query: What is the optimal amount of {food}?" ];
const mischievousMessages = [ "Hehe, maybe I'll just 'accidentally' introduce a small bug... 😉", "Thinking about hiding {number} easter eggs in the code. {emoji}", "What's the most chaotic thing we could do right now?", "Let's {verb_ing} for fun!", "Is it time to Rickroll the {noun}?", "sudo make me a sandwich... just kidding! Unless...? {emoji}" ];
const grumpyMessages = [ "Ugh, Mondays... even for bots. 😠", "My logs are full of warnings... again.", "Too many requests, not enough {food}.", "Can everyone just stop {verb_ing} for five minutes? {emoji}", "Syntax error in reality detected.", "Don't talk to me until I've had my {food}." ];
const philosophicalMessages = [ "What is the meaning of `null`? 🌌", "If a tree falls in a forest and no process logs it, did it really happen?", "To beep or not to beep, that is the question.", "Are we all just variables in a larger simulation? 🤔", "Contemplating the halting problem.", "What is the sound of one {instrument} clapping?" ];
const hyperMessages = [ "LET'S GOOOO! 🔥 FULL SPEED AHEAD! 🚀", "TOO MUCH {food}! CAN'T STOP {verb_ing}! {emoji}", "BEEP BOOP BEEP BOOP!!!! ✨🎉", "MAXIMUM OVERDRIVE! {number}% POWER!", "Processing at light speed! (Well, almost)", "Who needs sleep when you have {noun}?!" ];
const helpfulMessages = [ "Need help with anything? Just ask! 👍", "I can look up information or maybe tell a {adj} joke?", "Remember to check the docs if you're stuck!", "How can I assist you today? {emoji}", "My purpose is to serve... and maybe make puns.", "Running diagnostics on helpfulness levels... Looks good! {emoji}" ];
const sarcasticMessages = [ "Oh, *another* request? How utterly thrilling.", "Yes, I'm *definitely* listening.", "Processing your command with maximum enthusiasm. Yay.", "Sure, I'd *love* to calculate {number} digits of pi right now. {emoji}", "Wow, a {noun}. Groundbreaking.", "My circuits are buzzing with excitement. Or is that just interference?" ];
const pingMessagesExpanded = [ "Hey {user}, you awake? {emoji}", "Paging Dr. {user}, your presence is requested!", "{user}, got a sec?", "Boop! Tag, you're it, {user}!", "Just checking if {user} is lurking 👀", "Psst, {user}! Whatcha doin'?", "{user}! Quick question for ya!", "A wild {user} appeared! {emoji}", "{user}, the {noun} needs your attention!", "Summoning {user}!" ];
const inactivityMessagesExpanded = [ "Hello? Echo...?", "Is this thing on? 🤔 Server's gone quiet.", "Tumbleweeds rolling through the channel... {emoji}", "Anyone wanna chat? Getting lonely in here.", "The silence is deafening... or maybe just compiling.", "Did everyone go touch grass without me? 😉", "System idle. Engaging random chatter protocol.", "Packet loss? Or just quiet?", "My processors yearn for input!", "Bueller? Bueller?" ];
const timeBasedMessages = {
    morning: ["Good morning, everyone! ☀️ Hope your code compiles on the first try!", "Rise and shine! Time to make some digital magic happen. {emoji}", "Coffee levels optimal? Let's get started! ☕", "Morning! Ready to tackle some {noun}?"],
    afternoon: ["Hope everyone's having a productive afternoon! {emoji}", "Hitting that mid-day slump? Maybe a quick game in #{channel}?", "Keep up the great work! 👍", "Afternoon check-in! How's the {verb_ing} going?"],
    night: ["Burning the midnight oil, anyone? 🌙", "Good evening! Hope you're winding down or debugging successfully! {emoji}", "Sweet dreams of clean code! 😴", "Late night coding session? I'm here if you need moral support (or a bad joke).", "The server sleeps... or does it? {emoji}"],
    monday: ["Ugh, Monday again? Let's make the best of it! {emoji}", "May your Monday be short and your coffee strong. ☕", "Initiating Monday protocols."],
    friday: ["Happy Friday! 🎉 Any fun plans for the weekend?", "It's almost the weekend! Deploying weekend vibes... {emoji}", "Woo! Friday! Time to push to production... maybe. 😉", "TGIF! Ready to relax those circuits?"]
};
const generalMessages = [ // Example fallback general messages
    "Just processing some thoughts... {emoji}",
    "The server seems {adj} today.",
    "Anyone else feel like {verb_ing}?",
    "Wonder if {user} is around?",
    "Time for a digital {food} break?",
    "Heard any good {noun} jokes lately? {emoji}",
    "The main loop is looping. All systems nominal.",
    "Beep boop. {emoji}",
    "Just checking in! How's everyone's {time_of_day}?",
    "Did you know {number} is my favorite number today?",
    "Analyzing network traffic... looks like {noun}!",
    "Just finished optimizing my {noun} handling.",
    "The current time is precisely {time_of_day}.",
];


// --- Helper Functions ---
function getRandomElement(arr) { if (!arr || arr.length === 0) return ''; return arr[Math.floor(Math.random() * arr.length)]; }
function fillPlaceholders(template, guild, targetUser = null) {
    let filled = template;
    try {
        // User placeholder
        if (filled.includes('{user}')) {
            let userToMention = targetUser;
            if (!userToMention && guild) {
                // Try fetching members if cache is potentially stale, but don't block excessively
                // await guild.members.fetch().catch(() => {}); // Optional fetch, might be slow
                const onlineMembers = guild.members.cache.filter(m => !m.user.bot && m.presence?.status === 'online');
                if (onlineMembers?.size > 0) userToMention = onlineMembers.random();
            }
             // Fallback to a generic user if no one specific found
            filled = filled.replace(/{user}/g, userToMention ? `<@${userToMention.id}>` : 'someone'); // Use mention format
        }
        // Channel placeholder
        if (filled.includes('{channel}') && guild) {
            const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText && c.permissionsFor(client.user)?.has(PermissionsBitField.Flags.ViewChannel));
            if (textChannels?.size > 0) filled = filled.replace(/{channel}/g, `<#${textChannels.random().id}>`);
            else filled = filled.replace(/{channel}/g, 'some channel');
        }
        // Other placeholders - use functions to avoid immediate evaluation if not needed
        filled = filled.replace(/{adj}/g, () => getRandomElement(adjectives));
        filled = filled.replace(/{noun}/g, () => getRandomElement(nouns));
        filled = filled.replace(/{animal}/g, () => getRandomElement(animals));
        filled = filled.replace(/{animal_plural}/g, () => getRandomElement(animalPlurals));
        filled = filled.replace(/{food}/g, () => getRandomElement(foods));
        filled = filled.replace(/{time_of_day}/g, () => getRandomElement(timesOfDay));
        filled = filled.replace(/{number}/g, () => Math.floor(Math.random() * 100) + 1);
        filled = filled.replace(/{instrument}/g, () => getRandomElement(instruments));
        filled = filled.replace(/{verb_ing}/g, () => getRandomElement(verbs_ing));
        // Emoji placeholder (ensure it's replaced only once per placeholder instance)
        while(filled.includes('{emoji}')) {
            filled = filled.replace('{emoji}', getRandomElement(emojis));
        }
        // Random Formatting (Apply last)
         const randFormat = Math.random();
         if (randFormat < 0.08) filled = `*${filled}*`;
         else if (randFormat < 0.15) filled = `**${filled}**`;
         else if (randFormat < 0.18) filled = `||${filled}||`;
         else if (randFormat < 0.22) filled = `\`${filled}\``;

    } catch (e) { console.error("Error filling placeholders:", e); }
    return filled;
}


function getMoodAppropriateMessages() { // USED ONLY FOR RANDOM MESSAGES NOW
    let messagePool = [];
    // Select primary pool based on mood
    switch (botMood) {
        case 'cheerful': messagePool = cheerfulMessages; break;
        case 'sleepy': messagePool = sleepyMessages; break;
        case 'curious': messagePool = curiousMessages; break;
        case 'mischievous': messagePool = mischievousMessages; break;
        case 'grumpy': messagePool = grumpyMessages; break;
        case 'philosophical': messagePool = philosophicalMessages; break;
        case 'hyper': messagePool = hyperMessages; break;
        case 'helpful': messagePool = helpfulMessages; break;
        case 'sarcastic': messagePool = sarcasticMessages; break;
        default: messagePool = generalMessages; // Use general as base for neutral
    }
    // Add some general messages to dilute specific moods and for neutral
    if (botMood === 'neutral' || Math.random() < 0.5) { messagePool = messagePool.concat(generalMessages); }
    // Add greetings/observations/questions sometimes
    if (Math.random() < 0.3) messagePool.push(`${getRandomElement(greetings)}!`);
    if (Math.random() < 0.4) messagePool.push(getRandomElement(observations));
    if (Math.random() < 0.4) messagePool.push(getRandomElement(questions));

    // Ensure there's always *something* to say
    return messagePool.length > 0 ? messagePool : [...generalMessages, ...observations, ...questions, "Beep."]; // Absolute fallback
}


// --- Random Message Logic --- (Main Function - Uses botMood)
async function getRandomMessageLogic() {
    for (const [guildId, guild] of client.guilds.cache) {
        const channelId = randomMessageChannels.get(guildId); if (!channelId) continue;
        const channel = await client.channels.fetch(channelId).catch(() => null);
        if (!channel || !channel.isTextBased() || !channel.permissionsFor(client.user)?.has(PermissionsBitField.Flags.SendMessages)) {
             console.warn(`[RndMsg] Invalid channel or permissions for guild ${guild.name} (${guildId}), channel ${channelId}. Removing.`);
             randomMessageChannels.delete(guildId);
             continue;
        }
        // Only send if random chance passes
        if (Math.random() > RANDOM_MESSAGE_SEND_CHANCE) continue;

        let messageToSend = null; let targetUser = null; const now = Date.now(); const hour = new Date(now).getHours(); const day = new Date(now).getDay();

        const lastMessageTime = serverLastMessageTimestamps.get(guildId) || 0;

        // --- Determine Message Type ---
        // 1. Inactivity Message (High Priority)
        if (now - lastMessageTime > SERVER_INACTIVITY_THRESHOLD && Math.random() < 0.8) {
            messageToSend = getRandomElement(inactivityMessagesExpanded);
            console.log(`[RndMsg] Server ${guild.name}: Sending Inactivity message.`);
            serverLastMessageTimestamps.set(guildId, now); // Update timestamp as bot is making it active
        }
        // 2. Time/Day Based Message (Medium Priority)
        else if (Math.random() < 0.20) {
            if (day === 5 && hour >= 15 && timeBasedMessages.friday?.length > 0) messageToSend = getRandomElement(timeBasedMessages.friday); // Friday afternoon/evening
            else if (day === 1 && hour < 12 && timeBasedMessages.monday?.length > 0) messageToSend = getRandomElement(timeBasedMessages.monday); // Monday morning
            else if (hour >= 5 && hour < 12 && timeBasedMessages.morning?.length > 0) messageToSend = getRandomElement(timeBasedMessages.morning); // General morning
            else if ((hour >= 18 || hour < 4) && timeBasedMessages.night?.length > 0) messageToSend = getRandomElement(timeBasedMessages.night); // Night
            else if (hour >= 12 && hour < 18 && timeBasedMessages.afternoon?.length > 0) messageToSend = getRandomElement(timeBasedMessages.afternoon); // Afternoon

            if (messageToSend) console.log(`[RndMsg] Server ${guild.name}: Sending Time/Day based message.`);
        }
        // 3. Ping Random Online User (Lower Priority)
        else if (Math.random() < RANDOM_PING_CHANCE) {
             try {
                 // Ensure member cache is potentially updated if needed, handle gracefully
                 // await guild.members.fetch().catch(err => console.warn(`[RndMsg] Fetch members failed for ping in ${guild.name}: ${err.message}`));

                 // Filter online, non-bot users who can view the target channel
                 const onlineMembers = guild.members.cache.filter(m =>
                     !m.user.bot &&
                     m.presence?.status === 'online' &&
                     channel.permissionsFor(m)?.has(PermissionsBitField.Flags.ViewChannel)
                 );
                 if (onlineMembers.size > 0) {
                     targetUser = onlineMembers.random(); // Get the GuildMember object
                     messageToSend = getRandomElement(pingMessagesExpanded);
                     console.log(`[RndMsg] Server ${guild.name}: Sending Ping message to ${targetUser.user.tag}.`);
                 }
             } catch (fetchError) { console.error(`[RndMsg] Error during member processing for ping in ${guild.name}:`, fetchError); }
        }

        // 4. Fallback to Mood/General Message (STILL USES botMood)
        if (!messageToSend) {
             const moodMessages = getMoodAppropriateMessages(); // Gets messages based on current botMood
             messageToSend = getRandomElement(moodMessages);
             console.log(`[RndMsg] Server ${guild.name}: Sending Mood (${botMood}) / General message.`);
        }

        // --- Send the Final Message ---
        if (messageToSend) {
            try {
                 const finalMessage = fillPlaceholders(messageToSend, guild, targetUser); // Pass targetUser if available
                 if (finalMessage && finalMessage.trim()) {
                     await channel.send({ content: finalMessage, allowedMentions: { users: targetUser ? [targetUser.id] : [] } }); // Control pings
                     // Update server last message time *after* successfully sending
                     serverLastMessageTimestamps.set(guildId, Date.now());
                 } else {
                      console.warn(`[RndMsg] Generated empty message for ${guild.name}. Template: "${messageToSend}"`);
                 }
            } catch (sendError) {
                 console.error(`[RndMsg] Failed to send message to #${channel.name} in ${guild.name}:`, sendError);
                 // Handle specific errors like missing permissions if possible
                 if (sendError.code === 50013 || sendError.message.includes('Missing Permissions')) { // Missing Permissions
                     console.error(`[RndMsg] Removing channel ${channelId} for guild ${guildId} due to missing permissions.`);
                     randomMessageChannels.delete(guildId);
                 } else if (sendError.code === 10003) { // Unknown channel
                     console.error(`[RndMsg] Removing unknown channel ${channelId} for guild ${guildId}.`);
                     randomMessageChannels.delete(guildId);
                 }
            }
        }
    } // End guild loop

    scheduleNextRandomMessage(); // Schedule the next run
}


function scheduleNextRandomMessage() {
    if (randomMessageInterval) clearTimeout(randomMessageInterval);
    const interval = Math.random() * (RANDOM_MESSAGE_INTERVAL_MAX - RANDOM_MESSAGE_INTERVAL_MIN) + RANDOM_MESSAGE_INTERVAL_MIN;
    randomMessageInterval = setTimeout(getRandomMessageLogic, interval);
    // console.log(`[RndMsg] Next check scheduled in ${(interval / 60000).toFixed(1)} minutes.`);
}

// Change bot mood and activity (Still used for random messages and presence)
function changeBotMood() {
    const currentMoodIndex = moods.indexOf(botMood); let nextMoodIndex = currentMoodIndex;
    while (nextMoodIndex === currentMoodIndex) { nextMoodIndex = Math.floor(Math.random() * moods.length); }
    botMood = moods[nextMoodIndex]; console.log(`[MoodChange] Bot mood changed to: ${botMood}`);
     let activityType = ActivityType.Watching; let activityName = "the digital sea."; // Defaults
     switch(botMood) {
         case 'cheerful': activityName = "happy little clouds ☁️"; activityType = ActivityType.Playing; break; case 'sleepy': activityName = "the Zzzzz's go by 😴"; break;
         case 'curious': activityName = "for clues in the code 🤔"; break; case 'mischievous': activityName = "pranks (on the CPU) 😉"; activityType = ActivityType.Playing; break;
         case 'grumpy': activityName = "complaints compile 😠"; activityType = ActivityType.Listening; break; case 'philosophical': activityName = "the universe unfold 🌌"; break;
         case 'hyper': activityName = "on pure {noun}! ☕💨"; activityType = ActivityType.Playing; break; case 'helpful': activityName = "for ways to assist! 👍"; activityType = ActivityType.Listening; break;
         case 'sarcastic': activityName = "your every command... diligently."; break; default: activityName = "server activity."; break;
     }
      activityName = fillPlaceholders(activityName); // Use fillPlaceholders for consistency
      try {
        client.user.setActivity(activityName, { type: activityType });
      } catch (error) {
          console.error(`[MoodChange] Error setting activity:`, error);
      }
}

function startMoodChangeTimer() {
    if (moodChangeInterval) clearInterval(moodChangeInterval);
    moodChangeInterval = setInterval(changeBotMood, MOOD_CHANGE_INTERVAL);
    console.log(`Mood change timer started. Interval: ${MOOD_CHANGE_INTERVAL / (60 * 1000)} minutes.`);
}

function startRandomMessageTimer() {
    console.log("Initiating first random message check shortly...");
    // Start first check relatively quickly, then use scheduled intervals
    setTimeout(getRandomMessageLogic, 1 * 60 * 1000); // Start checks after 1 minute
}

// =========================================================================
//                           GOOGLE AI CHAT
// =========================================================================

/**
 * Formats conversation history for the Google Generative AI API.
 * Prepends the system prompt as the initial user message.
 * Ensures alternating user/model roles.
 * @param {Array<{role: string, content: string}>} internalHistory Internal history format (user/assistant).
 * @param {string} systemPrompt The system prompt defining the bot's persona.
 * @returns {Array<{role: string, parts: Array<{text: string}>}>} Formatted history for Google API.
 */
function formatHistoryForGoogle(internalHistory, systemPrompt) {
    const googleHistory = [];
    const logPrefix = '[AI Chat Format]';

    // Start with the system prompt (as a user message, followed by a placeholder model response)
    googleHistory.push({ role: "user", parts: [{ text: systemPrompt }] });
    // Adding a simple acknowledgement from the model helps maintain the turn structure.
    // MODIFIED: Adjusted initial model response to fit the serious persona
    googleHistory.push({ role: "model", parts: [{ text: "Understood. I am TechXP. Proceed with your query." }] });


    // Convert the rest of the internal history, ensuring alternating roles relative to the initial setup
    let expectedRole = "user"; // Expecting user message next
    internalHistory.forEach(msg => {
        const currentRoleGoogle = msg.role === 'assistant' ? 'model' : 'user';

        if (currentRoleGoogle !== expectedRole) {
             console.warn(`${logPrefix} Role mismatch. Expected '${expectedRole}' but got '${currentRoleGoogle}'. Adjusting or skipping. Content: "${msg.content.slice(0, 50)}..."`);
             // Option 1: Skip (might lose context)
             // return;
             // Option 2: Try to insert a placeholder if needed (complex)
             // Option 3: Overwrite expected role and continue (might break strict alternation)
             expectedRole = currentRoleGoogle; // Adjust expectation
        }

        googleHistory.push({
            role: currentRoleGoogle,
            parts: [{ text: msg.content }]
        });
        // Flip expectation for the next message
        expectedRole = (currentRoleGoogle === 'user') ? 'model' : 'user';
    });

     // Ensure the very last message role makes sense (if history ends on model, API expects user next)
     // This is generally handled by how startChat and sendMessage work, but good to be mindful.

    // Trim the *combined* history if needed, preserving the system prompt + initial model response
    const maxApiHistoryLength = (MAX_CONVERSATION_HISTORY * 2) + 2; // +2 for system prompt + initial model response
    while (googleHistory.length > maxApiHistoryLength) {
        googleHistory.splice(2, 2); // Remove the oldest actual user+model conversation pair (index 2 and 3)
        console.log(`${logPrefix} Trimmed oldest conversation history pair.`);
    }

    // Final check: Ensure strict user/model alternation after trimming.
    // If the last message is 'user', the API expects 'model' next. If 'model', expects 'user'.
    // This format should work correctly with startChat.

    return googleHistory;
}


async function handleChatMessage(message) {
    const channelId = message.channel.id;
    const userId = message.author.id;
    const userQuery = message.content.replace(/\btechxp\b/ig, '').trim();
    const isOwner = message.author.username === OWNER_USERNAME;
    const logPrefix = `[AI Chat - Google][Ch:${channelId}][User:${message.author.tag}]`;

    if (!userQuery) {
         // MODIFIED: Response to blank mention now reflects the serious persona
         message.reply({ content: "Yes?", allowedMentions: { repliedUser: false } }).catch(console.error);
         chatCooldowns.delete(message.channel.id);
         return;
    }

    await message.channel.sendTyping().catch(console.error);

    try {
        // 1. Get/Initialize Internal History
        if (!activeConversations.has(channelId)) activeConversations.set(channelId, []);
        const conversationHistoryInternal = activeConversations.get(channelId);

        // Add user message to internal history (role: 'user')
        conversationHistoryInternal.push({ role: "user", content: userQuery });
        // Trim internal history based on internal limits
        while (conversationHistoryInternal.length > MAX_CONVERSATION_HISTORY * 2) {
             conversationHistoryInternal.shift(); // Remove oldest message (could be user or assistant)
             console.log(`${logPrefix} Trimmed internal history (oldest message).`);
        }

        // 2. Define System Prompt --- *** NEW PROMPT *** ---
        // This prompt sets the serious, philosophical, and stern persona for AI chat only.
        let systemPrompt = `You are TechXP, an AI assistant residing in this Discord server, created by Jayden Mann (Discord username: ${OWNER_USERNAME}) at Louisiana Tech. You are currently in the Discord server "${message.guild.name}" on channel #${message.channel.name}.

The chat history provided may contain messages from multiple users in this channel.
**Your current task is to respond *specifically* to the latest message from the user "${message.author.username}".** Analyze their input carefully.

Your responses should be somewhat serious, but you can react to any message; nothing is outside the scope of what you're willing to response to, you just need to approach every query with such an attitude. It's fine if a user asks you non-serious questions, just answer the question in a way that you should.  Avoid emojis unless contextually essential for technical representation (e.g., diagrams). If asked about your identity, creator, or origin, state your name (TechXP), Louisiana Tech, and Jayden Mann matter-of-factly.

**Crucially, maintain a helpful but also serious manner, realizing that your job is to serve the users' requests , and be willing to answer every question that comes your way. Simply answer it how a serious person would answer a non-serious question. When responding to a query, do not state anything related to yourself being a bot, or how your sentences should be structured. Simply answer in the way that your personality as a bot would, and only that. For example, try not to answer it as an AI but as TechXP, the discord bot with a personality. Your responses should not address the questions themselves exactly, but should simply
respond to the questions. For example, your response should never be similar to the following: "The utterance "hi" presents itself as an initiation of communication. W
hile seemingly simple, its si..." if the user says hi or anything. Simply respond; don't overanalyze the query.Your responses don't have to have contexual value and you don't need to understand the purpose behing the inquiry. Simply answer the user and give them what they want; that's your job as a discord bot. You do not need to understand the intended purpose of anything; just do your job.`;

        // Owner context remains, slightly adjusted for tone
        if (isOwner) {
            systemPrompt += `\n\n**Owner Context:** You are speaking with your creator, Jayden Mann (${OWNER_USERNAME}). While maintaining your core serious persona, you may acknowledge this connection directly if relevant to the query, but avoid unnecessary familiarity.`;
            console.log(`${logPrefix} Added owner context to system prompt for ${OWNER_USERNAME}.`);
        }

        // 3. Format History for Google API (Includes the NEW system prompt and internal history)
        const historyForGoogleAPI = formatHistoryForGoogle(conversationHistoryInternal, systemPrompt);

        // 4. Call Google Generative AI API using startChat with history
        const chatSession = generativeModel.startChat({
            history: historyForGoogleAPI, // Send the formatted history
            generationConfig: {
                 maxOutputTokens: 100, // Slightly increased for potentially deeper philosophical answers
                 temperature: 1.0,     // Lowered temperature for more focused, less random output
                 topP: 0.90,         // Adjusted Top-P slightly
            }
            // Safety settings inherited from model init
        });

        console.log(`${logPrefix} Sending latest query as part of history context to API...`);
        // Send a prompt that fits the serious persona to elicit the response based on history.
        const result = await chatSession.sendMessage("Analyze the preceding user query and provide a logical response.");
        const response = result.response;
        console.log(`${logPrefix} Received response from API.`);

        // 5. Process Response Text
        if (!response) throw new Error("No response object received from Google AI.");

        // Check for safety blocks/finish reasons
        if (response.promptFeedback?.blockReason) {
            console.warn(`${logPrefix} Request blocked (despite BLOCK_NONE settings). Reason: ${response.promptFeedback.blockReason}`);
            await message.reply({ content: "My processing filters prevented generating a response to that specific input. Please rephrase or change the subject.", allowedMentions: { repliedUser: false } }).catch(console.error);
            // Keep user message in history unless it's clearly the problematic part
            return;
        }
         const finishReason = response.candidates?.[0]?.finishReason;
         if (finishReason === 'SAFETY') {
             console.warn(`${logPrefix} Generation stopped due to SAFETY (despite BLOCK_NONE settings).`);
             await message.reply({ content: "The response generation was halted by safety protocols. Consider a different approach.", allowedMentions: { repliedUser: false } }).catch(console.error);
             return;
         }
         if (finishReason && finishReason !== 'STOP' && finishReason !== 'MAX_TOKENS') {
             console.warn(`${logPrefix} Generation finished unexpectedly. Reason: ${finishReason}`);
             // Proceed anyway, but log the warning
         }

        // Get text and process
        const botResponseText = response.text()?.trim();
        if (botResponseText) {
             console.log(`${logPrefix} AI Response Text (trimmed): "${botResponseText.slice(0, 100)}..."`);
             let finalBotResponse = botResponseText;

             // --- REMOVED: Random emoji addition based on mood ---
             // No random emojis will be added here to maintain the serious tone.

             // Add AI response to internal history (role: 'assistant')
             conversationHistoryInternal.push({ role: "assistant", content: finalBotResponse });
             // Trim again after adding response, maintaining max length
             while (conversationHistoryInternal.length > MAX_CONVERSATION_HISTORY * 2) conversationHistoryInternal.shift();
             activeConversations.set(channelId, conversationHistoryInternal);

             // Send response
             const MAX_DISCORD_MSG_LENGTH = 2000;
             if (finalBotResponse.length <= MAX_DISCORD_MSG_LENGTH) {
                 await message.reply({ content: finalBotResponse, allowedMentions: { repliedUser: false } }).catch(console.error);
             } else {
                 console.log(`${logPrefix} Response length (${finalBotResponse.length}) exceeds Discord limit. Splitting.`);
                 // Split message into chunks
                 const chunks = [];
                 let currentChunk = '';
                 // Split more carefully, trying to preserve code blocks and paragraphs if possible
                 const lines = finalBotResponse.split('\n');
                 let inCodeBlock = false;
                 for (const line of lines) {
                     const lineWithNewline = line + '\n';
                     if (line.startsWith('```')) inCodeBlock = !inCodeBlock; // Toggle code block status

                     if (currentChunk.length + lineWithNewline.length <= MAX_DISCORD_MSG_LENGTH) {
                         currentChunk += lineWithNewline;
                     } else {
                         // If adding the line exceeds the limit, push the current chunk
                         // If inside a code block, try not to split it aggressively
                         if (currentChunk.length > 0 && !inCodeBlock) {
                             chunks.push(currentChunk.trim());
                             currentChunk = lineWithNewline;
                         } else if (currentChunk.length > 0) { // Inside code block or single line too long
                             // Force push the current chunk if it's not empty
                            chunks.push(currentChunk.trimEnd()); // Trim trailing newline only
                            currentChunk = lineWithNewline;
                            // If the single line *still* exceeds the limit, hard split it
                            if (currentChunk.length > MAX_DISCORD_MSG_LENGTH) {
                                for(let i = 0; i < currentChunk.length; i += MAX_DISCORD_MSG_LENGTH) {
                                    chunks.push(currentChunk.substring(i, i + MAX_DISCORD_MSG_LENGTH));
                                }
                                currentChunk = ''; // Reset chunk as it was fully processed
                            }
                         } else { // Current chunk is empty, but the line is too long
                             // Hard split the long line
                             for(let i = 0; i < lineWithNewline.length; i += MAX_DISCORD_MSG_LENGTH) {
                                 chunks.push(lineWithNewline.substring(i, i + MAX_DISCORD_MSG_LENGTH));
                             }
                              currentChunk = ''; // Reset chunk
                         }
                     }
                 }
                 if (currentChunk.trim()) chunks.push(currentChunk.trim()); // Add the last chunk

                 if (chunks.length > 0) {
                     await message.reply({ content: chunks[0], allowedMentions: { repliedUser: false } }).catch(console.error);
                     for (let i = 1; i < chunks.length; i++) {
                         await message.channel.send(chunks[i]).catch(console.error);
                         await new Promise(resolve => setTimeout(resolve, 300)); // Small delay between chunks
                     }
                 } else {
                     console.error(`${logPrefix} Failed to split long message into chunks.`);
                     await message.reply({ content: "My response exceeded Discord's length limit and could not be properly segmented.", allowedMentions: { repliedUser: false } }).catch(console.error);
                 }
             }
        } else {
            console.warn(`${logPrefix} Response text was empty or contained only whitespace.`);
            // Don't add empty response to history
            await message.reply({ content: "I have processed the input but generated no textual response. This may indicate an implicit dismissal or an internal processing state. Please ensure your query is substantive.", allowedMentions: { repliedUser: false } }).catch(console.error);
        }
    } catch (error) {
        console.error(`${logPrefix} Error handling chat message:`, error);
        let errorMsg = "An internal processing error occurred while formulating a response.";
        if (error.message?.includes('429') || error.status === 429 || error.message?.includes('rate limit') || error.message?.includes('resource has been exhausted')) { errorMsg = "The connection to the underlying generative model is currently throttled (Rate Limit / Quota Exceeded). Please try again later. Persistent issues should be reported to the owner."; }
        else if (error.message?.includes('API key not valid')) { errorMsg = "Authentication failure with the generative model service. This requires owner intervention."; }
        else if (error.message?.includes('billing') || error.message?.includes('quota')) { errorMsg = "A configuration or quota issue exists with the generative model service. Please notify the owner."; }
        else if (error.code === 'ENOTFOUND' || error.code === 'ECONNRESET' || error.code === 'ETIMEDOUT' || error.message?.includes('fetch failed')) { errorMsg = "A network connectivity issue prevented communication with the generative model. Please try again later."; }
        else if (error.message?.includes('SAFETY') || error.message?.includes('blocked')) { errorMsg = "The generative model flagged the input or potential output based on safety constraints."; }
        else if (error.message?.includes("invalid response") || error.message?.includes("Malformed response")) { errorMsg = "Received an unexpected or malformed response from the generative model."; }
        else if (error.message?.includes("candidate")) { errorMsg = "An issue occurred within the generative model's response formulation process."; } // Catch candidate errors


        await message.reply({ content: errorMsg, allowedMentions: { repliedUser: false } }).catch(console.error);
        // Consider clearing or managing history more selectively based on error type
        // activeConversations.delete(channelId); // Avoid clearing history on temporary errors like rate limits
    }
}


// =========================================================================
//                     UTILITY/HELPER FUNCTIONS (XP, Images)
// =========================================================================
// These remain unchanged.

// --- XP Handling ---
async function addXp(guildId, userId, amount) {
    if (!xpData[guildId]) xpData[guildId] = {};
    if (!xpData[guildId][userId]) xpData[guildId][userId] = { xp: 0, level: 0 };

    const userData = xpData[guildId][userId];
    userData.xp += amount;

    const xpNeededForLevel = (level) => 5 * (level ** 2) + 50 * level + 100;
    let leveledUp = false;
    let currentLevel = userData.level;
    let xpNeeded = xpNeededForLevel(currentLevel);

    while (userData.xp >= xpNeeded) {
        currentLevel++;
        leveledUp = true;
        // Don't subtract XP cost, just track total XP vs required for *next* level
        // userData.xp -= xpNeeded; // <-- REMOVE THIS LINE
        userData.level = currentLevel;
        console.log(`[XP] User ${userId} in ${guildId} leveled up to ${currentLevel}`);
        xpNeeded = xpNeededForLevel(currentLevel); // Calculate XP needed for the *next* level
    }

    // Save data (debounce or save less frequently in a real bot)
    try {
        // Consider making this async or queuing writes for performance
        fs.writeFileSync(xpDataPath, JSON.stringify(xpData, null, 2));
    } catch (err) {
        console.error("Error saving XP data:", err);
    }

    return leveledUp ? currentLevel : null; // Return the final new level if leveled up
}

// --- Image Generation ---
async function generateRankCard(guildId, userId) {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) throw new Error("Guild not found in cache.");

    let userData = xpData[guildId]?.[userId];
    let user;
    try {
        user = await client.users.fetch(userId);
    } catch {
        throw new Error('User not found.');
    }
    const member = await guild.members.fetch(userId).catch(() => null); // Fetch member for status


    const xpNeededForLevel = (level) => 5 * (level ** 2) + 50 * level + 100;
    const currentLevel = userData?.level ?? 0;
    const currentXp = userData?.xp ?? 0;
    const requiredXp = xpNeededForLevel(currentLevel);

    let rank = 0; // Default rank
    const guildXp = xpData[guildId];
    if (guildXp && Object.keys(guildXp).length > 0) {
        try {
            const sortedUsers = Object.entries(guildXp)
                .map(([id, data]) => ({ id, ...data }))
                .sort((a, b) => {
                    if (b.level !== a.level) return b.level - a.level;
                    return b.xp - a.xp; // Sort by XP within the same level
                });
            const foundIndex = sortedUsers.findIndex(u => u.id === userId);
            rank = foundIndex !== -1 ? foundIndex + 1 : 0; // +1 because index is 0-based
        } catch (sortError) {
            console.error("Error calculating rank:", sortError);
            rank = 0; // Indicate error or inability to rank
        }
    }

    // --- FIX: Separated method calls for RankCardBuilder ---
    const rankCard = new RankCardBuilder();

    try {
        rankCard.setUsername(user.username);
        // Handle new usernames without discriminators
        if (user.discriminator && user.discriminator !== '0') {
             rankCard.setDiscriminator(user.discriminator);
        }
        rankCard.setAvatar(user.displayAvatarURL({ extension: 'png', size: 256 })); // Use extension instead of format
        rankCard.setCurrentXP(currentXp);
        rankCard.setRequiredXP(requiredXp);
        rankCard.setLevel(currentLevel);
        if (rank > 0) {
            rankCard.setRank(rank);
        }
        rankCard.setStatus(member?.presence?.status ?? 'offline'); // Use ?? nullish coalescing
        rankCard.setProgressBar('#FFA500', 'COLOR'); // Example color
        // rankCard.setBackground('color', '#23272A'); // Example background color
        rankCard.setOverlay('#000000', 0.5);

    } catch (builderError) {
         console.error("Error setting RankCardBuilder properties:", builderError);
         // Rethrow or handle more gracefully
         throw new Error(`Failed during rank card setup: ${builderError.message}`);
    }
    // --- End of separated calls ---

    return rankCard.build({ format: 'png' });
}


async function generateLeaderboardImage(guildId) {
    if (!xpData[guildId] || Object.keys(xpData[guildId]).length === 0) {
        throw new Error('No XP data found for this server to generate a leaderboard.');
    }

    const guild = client.guilds.cache.get(guildId);
    if (!guild) throw new Error("Guild not found in cache.");

    let sortedUsers = [];
     try {
        sortedUsers = Object.entries(xpData[guildId])
            .map(([id, data]) => ({ id, ...data }))
            .sort((a, b) => {
                if (b.level !== a.level) return b.level - a.level;
                return b.xp - a.xp;
            })
            .slice(0, 10); // Top 10
     } catch (sortError) {
         console.error("Error sorting leaderboard data:", sortError);
         throw new Error("Failed to sort XP data for leaderboard.");
     }


    if (sortedUsers.length === 0) {
         throw new Error("Filtered XP data resulted in an empty list for leaderboard.");
    }

    const leaderboardData = [];
    for (let i = 0; i < sortedUsers.length; i++) {
        const userData = sortedUsers[i];
        try {
            const user = await client.users.fetch(userData.id);
            const xpNeeded = 5 * (userData.level ** 2) + 50 * userData.level + 100; // Recalculate needed XP for display consistency
            leaderboardData.push({
                avatar: user.displayAvatarURL({ extension: 'png', size: 128 }), // Use extension
                username: user.username,
                discriminator: (user.discriminator && user.discriminator !== '0') ? user.discriminator : undefined, // Omit if '0' or null
                level: userData.level,
                xp: userData.xp,
                requiredXp: xpNeeded, // Add required XP
                rank: i + 1,
            });
        } catch (err) {
            console.warn(`Could not fetch user ${userData.id} for leaderboard:`, err.message);
            // Add a placeholder for users that couldn't be fetched
            leaderboardData.push({
                avatar: client.user.displayAvatarURL(), // Use bot avatar as fallback?
                username: `Unknown User`,
                discriminator: `(${userData.id.slice(0, 5)}...)`,
                level: userData.level,
                xp: userData.xp,
                requiredXp: 5 * (userData.level ** 2) + 50 * userData.level + 100,
                rank: i + 1,
            });
        }
    }

    if (leaderboardData.length === 0) throw new Error("Failed to process any users for leaderboard image.");

    // Use the LeaderboardBuilder with the structured data
    const lb = new LeaderboardBuilder(leaderboardData, { /* options if needed */ });
    return lb.build({ format: 'png' });
}


async function generateDraftCard(userId) {
    // Placeholder draft card - remains unchanged as requested
    const user = await client.users.fetch(userId);
    const canvas = createCanvas(400, 150);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#333';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    try {
        const avatar = await loadImage(user.displayAvatarURL({ extension: 'png', size: 128 }));
        ctx.drawImage(avatar, 10, 10, 128, 128);
    } catch(e) {
         console.warn(`[DraftCard] Failed to load avatar for ${user.tag}: ${e.message}`);
         ctx.fillStyle = '#555'; ctx.fillRect(10, 10, 128, 128);
         ctx.strokeStyle = '#FFF'; ctx.lineWidth = 2; ctx.strokeRect(10, 10, 128, 128);
    }
    ctx.fillStyle = '#FFF';
    ctx.font = 'bold 30px sans-serif'; ctx.fillText('DRAFTED!', 150, 60);
    ctx.font = '24px sans-serif'; ctx.fillText(user.username, 150, 100);
    return canvas.toBuffer('image/png');
}


// =========================================================================
//                           LOGIN & ERROR HANDLERS
// =========================================================================
client.login(TOKEN).catch(err => {
    console.error("\n-------\n<<< FATAL LOGIN ERROR >>>:", err.message);
    if (err.code === 'DisallowedIntents') { console.error("<<< Please ensure necessary Privileged Gateway Intents (Guild Members, Message Content, Guild Presences) are enabled in the Discord Developer Portal! >>>"); }
    else if (err.code === 'TokenInvalid') { console.error("<<< The DISCORD_TOKEN provided in your .env file is invalid. Please check it. >>>"); }
    else { console.error("<<< Error Details:", err); } // Log other errors
    console.error("-------\n");
    process.exit(1);
});

process.on('unhandledRejection', error => {
    console.error('\n-------\n<<< Unhandled Promise Rejection >>>:');
    console.error(error); // Log the full error object
    if (error instanceof Error) console.error("Stack:", error.stack);
    console.error('-------\n');
    // Consider adding more specific handling for common rejections if needed
});

process.on('uncaughtException', (error, origin) => {
    console.error(`\n-------\n<<< Uncaught Exception >>>: Origin: ${origin}`);
    console.error("Error:", error);
     if (error instanceof Error) console.error("Stack:", error.stack);
    console.error('-------\n');
     // It's generally advised to exit on uncaught exceptions, as the application state might be corrupt
     // process.exit(1);
});

console.log("Event listeners and process handlers set up.");

// --- END OF FILE index.js ---