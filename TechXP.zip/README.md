# TechXP Discord Bot - Running Instructions (Linux)
# MADE BY JAYDEN MANN
# WHAT THE SIGMA LIGMA 

This guide explains how to run the TechXP Discord bot on a Linux server.

## Prerequisites

Ensure the following are installed on your system:

1.  **Node.js (LTS version recommended, e.g., v18.x or v20.x):**
    *   *(Check: `node -v`)*
    *   **Ubuntu/Debian Install:**
        ```bash
        sudo apt-get update
        sudo apt-get install -y nodejs npm
        ```
    *   **Fedora Install:**
        ```bash
        sudo dnf install nodejs -y
        ```
    *   *(Includes `npm`)*

2.  **FFmpeg:**
    *   *(Check: `ffmpeg -version`)*
    *   **Ubuntu/Debian Install:**
        ```bash
        sudo apt-get update
        sudo apt-get install -y ffmpeg
        ```
    *   **Fedora Install:**
        ```bash
        sudo dnf install ffmpeg -y
        ```

## Setup

1.  **Navigate to Bot Directory:**
    Open your terminal and go into the directory containing the bot's files (`index.js`, `package.json`, `.env`)

2.  **Install Dependencies:**
    Run the following command to install all necessary packages listed in `package.json`.
    ```bash
    npm install
    ```

## Running the Bot (Using PM2 - Recommended)

Using PM2 keeps the bot running in the background and restarts it automatically if it crashes or the server reboots.

1.  **Install PM2:**
    ```bash
    sudo npm install pm2 -g
    ```

2.  **Start the Bot:**
    Make sure you are still in the bot's directory.
    ```bash
    pm2 start index.js --name "TechXP-Bot"
    ```

3.  **Check Status:**
    See if the bot is running (`online` status).
    ```bash
    pm2 list
    ```

4.  **View Logs:**
    Check for errors or activity.
    ```bash
    pm2 logs TechXP-Bot
    ```
    *(Press Ctrl+C to stop viewing logs)*

5.  **Enable Auto-Restart on Server Reboot:**
    *   Run: `pm2 startup`
    *   *(Follow the instructions it gives, which usually involves running a command with `sudo`)*
    *   Then run: `pm2 save`

## Controlling the Bot (PM2 Commands)

*   **Stop:** `pm2 stop TechXP-Bot`
*   **Restart:** `pm2 restart TechXP-Bot`
*   **Delete from PM2:** `pm2 delete TechXP-Bot`

---

The bot should now be running persistently. If you encounter issues, check the logs using `pm2 logs TechXP-Bot`.